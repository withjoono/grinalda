import {
  Controller,
  Get,
  Post,
  Delete,
  Body,
  Param,
  ParseIntPipe,
  Query,
  Patch,
  UseInterceptors,
  UploadedFile,
} from '@nestjs/common';
import { CoreUniversityService } from '../services/core-university.service';
import { UniversityEntity } from 'src/database/entities/core/university.entity';
import { PaginationDto } from 'src/common/dtos/pagination.dto';
import {
  CreateUniversityDto,
  UpdateUniversityDto,
} from '../dtos/university.dto';
import { Roles } from 'src/auth/decorators/roles.decorator';
import { ApiOperation } from '@nestjs/swagger';
import { FileInterceptor } from '@nestjs/platform-express';
import { diskStorage } from 'multer';
import { extname } from 'path';

@Controller('core/universities')
export class CoreUniversityController {
  constructor(private readonly universityService: CoreUniversityService) {}

  @Get()
  async findAll(@Query() query: PaginationDto): Promise<{
    universities: UniversityEntity[];
    total: number;
    page: number;
    limit: number;
  }> {
    const { universities, total } = await this.universityService.findAll(query);
    return {
      universities,
      total,
      page: query.page,
      limit: query.limit,
    };
  }

  @Get(':id')
  async findOne(
    @Param('id', ParseIntPipe) id: number,
  ): Promise<UniversityEntity> {
    return this.universityService.findOne(id);
  }

  @Post()
  @Roles(['ROLE_ADMIN'])
  async create(@Body() dto: CreateUniversityDto): Promise<UniversityEntity> {
    return this.universityService.create(dto);
  }

  @Patch(':id')
  @Roles(['ROLE_ADMIN'])
  async update(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateUniversityDto,
  ): Promise<UniversityEntity> {
    return this.universityService.update(id, dto);
  }

  @Delete(':id')
  @Roles(['ROLE_ADMIN'])
  async remove(@Param('id', ParseIntPipe) id: number): Promise<void> {
    return this.universityService.remove(id);
  }

  @Post('upload')
  @Roles(['ROLE_ADMIN'])
  @ApiOperation({
    summary: '[관리자] 대학 목록 엑셀 업로드',
  })
  @UseInterceptors(
    FileInterceptor('file', {
      storage: diskStorage({
        destination: './uploads',
        filename: (req, file, cb) => {
          const uniqueSuffix =
            Date.now() + '-' + Math.round(Math.random() * 1e9);
          cb(null, `${uniqueSuffix}${extname(file.originalname)}`);
        },
      }),
    }),
  )
  async uploadFile(@UploadedFile() file: Express.Multer.File) {
    await this.universityService.syncUniversitiesWithExcel(file.path);
    return { message: 'File uploaded and processed successfully' };
  }
}
