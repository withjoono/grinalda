import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  UseInterceptors,
  UploadedFile,
  ParseIntPipe,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiOperation } from '@nestjs/swagger';
import { Roles } from 'src/auth/decorators/roles.decorator';
import { diskStorage } from 'multer';
import { extname } from 'path';
import { RegularAdmissionEntity } from 'src/database/entities/core/regular-admission.entity';
import {
  CreateRegularAdmissionDto,
  UpdateRegularAdmissionDto,
} from '../dtos/regular-admission.dto';
import { CoreRegularAdmissionService } from '../services/core-regular-admission.service';

@Controller('core/regular-admission')
export class CoreRegularAdmissionController {
  constructor(
    private readonly regularAdmissionService: CoreRegularAdmissionService,
  ) {}

  @Get()
  @Roles(['ROLE_ADMIN'])
  @ApiOperation({ summary: '정시 전형 목록 조회' })
  async findAll(): Promise<RegularAdmissionEntity[]> {
    return this.regularAdmissionService.findAll();
  }

  @Get(':id')
  @Roles(['ROLE_ADMIN'])
  @ApiOperation({ summary: '개별 정시 전형 조회' })
  async findOne(
    @Param('id', ParseIntPipe) id: number,
  ): Promise<RegularAdmissionEntity> {
    return this.regularAdmissionService.findOne(id);
  }

  @Post()
  @Roles(['ROLE_ADMIN'])
  @ApiOperation({ summary: '[관리자] 정시 전형 추가' })
  async create(
    @Body() createRegularAdmissionDto: CreateRegularAdmissionDto,
  ): Promise<RegularAdmissionEntity> {
    return this.regularAdmissionService.create(createRegularAdmissionDto);
  }

  @Patch(':id')
  @Roles(['ROLE_ADMIN'])
  @ApiOperation({ summary: '[관리자] 정시 전형 수정' })
  async update(
    @Param('id', ParseIntPipe) id: number,
    @Body() updateRegularAdmissionDto: UpdateRegularAdmissionDto,
  ): Promise<RegularAdmissionEntity> {
    return this.regularAdmissionService.update(id, updateRegularAdmissionDto);
  }

  @Delete(':id')
  @Roles(['ROLE_ADMIN'])
  @ApiOperation({ summary: '[관리자] 정시 전형 삭제' })
  async remove(@Param('id', ParseIntPipe) id: number): Promise<void> {
    return this.regularAdmissionService.remove(id);
  }

  @Post('upload')
  @Roles(['ROLE_ADMIN'])
  @ApiOperation({ summary: '[관리자] 정시 전형 목록 엑셀 업로드' })
  @UseInterceptors(
    FileInterceptor('file', {
      storage: diskStorage({
        destination: './uploads',
        filename: (req, file, cb) => {
          const uniqueSuffix =
            Date.now() + '-' + Math.round(Math.random() * 1e9);
          cb(null, `${uniqueSuffix}${extname(file.originalname)}`);
        },
      }),
    }),
  )
  async uploadFile(@UploadedFile() file: Express.Multer.File) {
    await this.regularAdmissionService.syncWithExcel(file.path);
    return { message: 'File uploaded and processed successfully' };
  }
}
