import {
  Controller,
  Get,
  Post,
  Delete,
  Param,
  Body,
  ParseIntPipe,
  Patch,
} from '@nestjs/common';
import { CoreAdmissionSubtypeService } from '../services/core-admission-subtype.service';
import { AdmissionSubtypeEntity } from 'src/database/entities/core/admission-subtype.entity';
import {
  CreateAdmissionSubtypeDto,
  UpdateAdmissionSubtypeDto,
} from '../dtos/admission-subtype.dto';

@Controller('core/admission-subtypes')
export class CoreAdmissionSubtypeController {
  constructor(
    private readonly admissionSubtypeService: CoreAdmissionSubtypeService,
  ) {}

  @Get()
  async findAll(): Promise<AdmissionSubtypeEntity[]> {
    return this.admissionSubtypeService.findAll();
  }

  @Get(':id')
  async findOne(
    @Param('id', ParseIntPipe) id: number,
  ): Promise<AdmissionSubtypeEntity> {
    return this.admissionSubtypeService.findOne(id);
  }

  @Post()
  async create(
    @Body() createAdmissionSubtypeDto: CreateAdmissionSubtypeDto,
  ): Promise<AdmissionSubtypeEntity> {
    return this.admissionSubtypeService.create(createAdmissionSubtypeDto);
  }

  @Patch(':id')
  async update(
    @Param('id', ParseIntPipe) id: number,
    @Body() updateAdmissionSubtypeDto: UpdateAdmissionSubtypeDto,
  ): Promise<AdmissionSubtypeEntity> {
    return this.admissionSubtypeService.update(id, updateAdmissionSubtypeDto);
  }

  @Delete(':id')
  async remove(@Param('id', ParseIntPipe) id: number): Promise<void> {
    return this.admissionSubtypeService.remove(id);
  }
}
