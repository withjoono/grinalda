import {
  Controller,
  Get,
  Post,
  Patch,
  Delete,
  Param,
  Body,
  Query,
  ParseIntPipe,
  UseInterceptors,
  UploadedFile,
} from '@nestjs/common';
import { Roles } from 'src/auth/decorators/roles.decorator';
import { ApiOperation } from '@nestjs/swagger';
import { CoreRecruitmentUnitService } from '../services/core-recruitment.service';
import { RecruitmentUnitEntity } from 'src/database/entities/core/recruitment-unit.entity';
import {
  CreateRecruitmentUnitDto,
  UpdateRecruitmentUnitDto,
} from '../dtos/recruitment.dto';
import { FileInterceptor } from '@nestjs/platform-express';
import { diskStorage } from 'multer';
import { extname } from 'path';

@Controller('core/recruitment')
export class CoreRecruitmentController {
  constructor(
    private readonly recruitmentService: CoreRecruitmentUnitService,
  ) {}

  @Get()
  @ApiOperation({
    summary: '전형별 모집단위 목록 조회',
  })
  async findAllByAdmission(
    @Query('admission_id', ParseIntPipe) admissionId: number,
  ): Promise<RecruitmentUnitEntity[]> {
    return this.recruitmentService.findAllByAdmission(admissionId);
  }

  @Get(':id')
  @ApiOperation({
    summary: '개별 모집단위 조회',
  })
  async findOne(
    @Param('id', ParseIntPipe) id: number,
  ): Promise<RecruitmentUnitEntity> {
    return this.recruitmentService.findOne(id);
  }

  @Post()
  @Roles(['ROLE_ADMIN'])
  @ApiOperation({
    summary: '[관리자] 모집단위 추가',
  })
  async create(
    @Body() createRecruitmentUnitDto: CreateRecruitmentUnitDto,
  ): Promise<RecruitmentUnitEntity> {
    return this.recruitmentService.create(createRecruitmentUnitDto);
  }

  @Patch(':id')
  @Roles(['ROLE_ADMIN'])
  @ApiOperation({
    summary: '[관리자] 모집단위 수정',
  })
  async update(
    @Param('id', ParseIntPipe) id: number,
    @Body() updateRecruitmentUnitDto: UpdateRecruitmentUnitDto,
  ): Promise<RecruitmentUnitEntity> {
    return this.recruitmentService.update(id, updateRecruitmentUnitDto);
  }

  @Delete(':id')
  @Roles(['ROLE_ADMIN'])
  @ApiOperation({
    summary: '[관리자] 모집단위 삭제',
  })
  async remove(@Param('id', ParseIntPipe) id: number): Promise<void> {
    return this.recruitmentService.remove(id);
  }

  @Post('upload/subject')
  @Roles(['ROLE_ADMIN'])
  @ApiOperation({
    summary: '[관리자] 모집단위(교과) 목록 엑셀 업로드',
  })
  @UseInterceptors(
    FileInterceptor('file', {
      storage: diskStorage({
        destination: './uploads',
        filename: (req, file, cb) => {
          const uniqueSuffix =
            Date.now() + '-' + Math.round(Math.random() * 1e9);
          cb(null, `${uniqueSuffix}${extname(file.originalname)}`);
        },
      }),
    }),
  )
  async uploadSubjectFile(@UploadedFile() file: Express.Multer.File) {
    await this.recruitmentService.syncSubjectRecruitmentUnitsWithExcel(
      file.path,
    );
    return { message: 'File uploaded and processed successfully' };
  }

  @Post('upload/comprehensive')
  @Roles(['ROLE_ADMIN'])
  @ApiOperation({
    summary: '[관리자] 모집단위(학종) 목록 엑셀 업로드',
  })
  @UseInterceptors(
    FileInterceptor('file', {
      storage: diskStorage({
        destination: './uploads',
        filename: (req, file, cb) => {
          const uniqueSuffix =
            Date.now() + '-' + Math.round(Math.random() * 1e9);
          cb(null, `${uniqueSuffix}${extname(file.originalname)}`);
        },
      }),
    }),
  )
  async uploadComprehensiveFile(@UploadedFile() file: Express.Multer.File) {
    await this.recruitmentService.syncComprehensiveRecruitmentUnitsWithExcel(
      file.path,
    );
    return { message: 'File uploaded and processed successfully' };
  }

  @Post('upload/pass-fail')
  @Roles(['ROLE_ADMIN'])
  @ApiOperation({
    summary: '[관리자] 모집단위 합불데이터 업로드',
  })
  @UseInterceptors(
    FileInterceptor('file', {
      storage: diskStorage({
        destination: './uploads',
        filename: (req, file, cb) => {
          const uniqueSuffix =
            Date.now() + '-' + Math.round(Math.random() * 1e9);
          cb(null, `${uniqueSuffix}${extname(file.originalname)}`);
        },
      }),
    }),
  )
  async uploadPassFailRecordsFile(@UploadedFile() file: Express.Multer.File) {
    await this.recruitmentService.syncPassFailRecordsWithExcel(file.path);
    return { message: 'File uploaded and processed successfully' };
  }
}
