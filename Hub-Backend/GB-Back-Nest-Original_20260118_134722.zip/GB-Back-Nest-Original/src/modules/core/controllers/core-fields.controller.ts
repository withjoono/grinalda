import {
  Controller,
  Get,
  Post,
  Delete,
  Param,
  Body,
  ParseIntPipe,
  Patch,
  UseInterceptors,
  UploadedFile,
} from '@nestjs/common';
import { CoreFieldsService } from '../services/core-fields.service';
import { MajorFieldEntity } from 'src/database/entities/core/major-field.entity';
import { MidFieldEntity } from 'src/database/entities/core/mid-field.entity';
import { MinorFieldEntity } from 'src/database/entities/core/minor-field.entity';
import { GeneralFieldEntity } from 'src/database/entities/core/general-field.entity';
import {
  CreateGeneralFieldDto,
  CreateMajorFieldDto,
  CreateMidFieldDto,
  CreateMinorFieldDto,
  UpdateGeneralFieldDto,
  UpdateMajorFieldDto,
  UpdateMidFieldDto,
  UpdateMinorFieldDto,
} from '../dtos/fields.dto';
import { Roles } from 'src/auth/decorators/roles.decorator';
import { ApiOperation } from '@nestjs/swagger';
import { FileInterceptor } from '@nestjs/platform-express';
import { diskStorage } from 'multer';
import { extname } from 'path';

@Controller('core/fields')
export class CoreFieldsController {
  constructor(private readonly coreFieldsService: CoreFieldsService) {}

  // MajorField endpoints
  @Get('major')
  getAllMajorFields(): Promise<MajorFieldEntity[]> {
    return this.coreFieldsService.getAllMajorFields();
  }

  @Get('major/:id')
  getMajorFieldById(
    @Param('id', ParseIntPipe) id: number,
  ): Promise<MajorFieldEntity> {
    return this.coreFieldsService.getMajorFieldById(id);
  }

  @Post('major')
  @Roles(['ROLE_ADMIN'])
  createMajorField(
    @Body() createMajorFieldDto: CreateMajorFieldDto,
  ): Promise<MajorFieldEntity> {
    return this.coreFieldsService.createMajorField(createMajorFieldDto);
  }

  @Patch('major/:id')
  @Roles(['ROLE_ADMIN'])
  updateMajorField(
    @Param('id', ParseIntPipe) id: number,
    @Body() updateMajorFieldDto: UpdateMajorFieldDto,
  ): Promise<MajorFieldEntity> {
    return this.coreFieldsService.updateMajorField(id, updateMajorFieldDto);
  }

  @Delete('major/:id')
  @Roles(['ROLE_ADMIN'])
  deleteMajorField(@Param('id', ParseIntPipe) id: number): Promise<void> {
    return this.coreFieldsService.deleteMajorField(id);
  }

  // MidField endpoints
  @Get('mid')
  getAllMidFields(): Promise<MidFieldEntity[]> {
    return this.coreFieldsService.getAllMidFields();
  }

  @Get('mid/:id')
  getMidFieldById(
    @Param('id', ParseIntPipe) id: number,
  ): Promise<MidFieldEntity> {
    return this.coreFieldsService.getMidFieldById(id);
  }

  @Post('mid')
  @Roles(['ROLE_ADMIN'])
  createMidField(
    @Body() createMidFieldDto: CreateMidFieldDto,
  ): Promise<MidFieldEntity> {
    return this.coreFieldsService.createMidField(createMidFieldDto);
  }

  @Patch('mid/:id')
  @Roles(['ROLE_ADMIN'])
  updateMidField(
    @Param('id', ParseIntPipe) id: number,
    @Body() updateMidFieldDto: UpdateMidFieldDto,
  ): Promise<MidFieldEntity> {
    return this.coreFieldsService.updateMidField(id, updateMidFieldDto);
  }

  @Delete('mid/:id')
  @Roles(['ROLE_ADMIN'])
  deleteMidField(@Param('id', ParseIntPipe) id: number): Promise<void> {
    return this.coreFieldsService.deleteMidField(id);
  }

  // MinorField endpoints
  @Get('minor')
  getAllMinorFields(): Promise<MinorFieldEntity[]> {
    return this.coreFieldsService.getAllMinorFields();
  }

  @Get('minor/:id')
  getMinorFieldById(
    @Param('id', ParseIntPipe) id: number,
  ): Promise<MinorFieldEntity> {
    return this.coreFieldsService.getMinorFieldById(id);
  }

  @Post('minor')
  @Roles(['ROLE_ADMIN'])
  createMinorField(
    @Body() createMinorFieldDto: CreateMinorFieldDto,
  ): Promise<MinorFieldEntity> {
    return this.coreFieldsService.createMinorField(createMinorFieldDto);
  }

  @Patch('minor/:id')
  @Roles(['ROLE_ADMIN'])
  updateMinorField(
    @Param('id', ParseIntPipe) id: number,
    @Body() updateMinorFieldDto: UpdateMinorFieldDto,
  ): Promise<MinorFieldEntity> {
    return this.coreFieldsService.updateMinorField(id, updateMinorFieldDto);
  }

  @Delete('minor/:id')
  @Roles(['ROLE_ADMIN'])
  deleteMinorField(@Param('id', ParseIntPipe) id: number): Promise<void> {
    return this.coreFieldsService.deleteMinorField(id);
  }

  // GeneralField endpoints
  @Get('general')
  getAllGeneralFields(): Promise<GeneralFieldEntity[]> {
    return this.coreFieldsService.getAllGeneralFields();
  }

  @Get('general/:id')
  getGeneralFieldById(
    @Param('id', ParseIntPipe) id: number,
  ): Promise<GeneralFieldEntity> {
    return this.coreFieldsService.getGeneralFieldById(id);
  }

  @Post('general')
  @Roles(['ROLE_ADMIN'])
  createGeneralField(
    @Body() createGeneralFieldDto: CreateGeneralFieldDto,
  ): Promise<GeneralFieldEntity> {
    return this.coreFieldsService.createGeneralField(createGeneralFieldDto);
  }

  @Patch('general/:id')
  @Roles(['ROLE_ADMIN'])
  updateGeneralField(
    @Param('id', ParseIntPipe) id: number,
    @Body() updateGeneralFieldDto: UpdateGeneralFieldDto,
  ): Promise<GeneralFieldEntity> {
    return this.coreFieldsService.updateGeneralField(id, updateGeneralFieldDto);
  }

  @Delete('general/:id')
  @Roles(['ROLE_ADMIN'])
  deleteGeneralField(@Param('id', ParseIntPipe) id: number): Promise<void> {
    return this.coreFieldsService.deleteGeneralField(id);
  }

  @Post('upload')
  @Roles(['ROLE_ADMIN'])
  @ApiOperation({
    summary: '[관리자] [대/중/소 계열] 엑셀 업로드 (기존껀 지워지지 않음)',
  })
  @UseInterceptors(
    FileInterceptor('file', {
      storage: diskStorage({
        destination: './uploads',
        filename: (req, file, cb) => {
          const uniqueSuffix =
            Date.now() + '-' + Math.round(Math.random() * 1e9);
          cb(null, `${uniqueSuffix}${extname(file.originalname)}`);
        },
      }),
    }),
  )
  async uploadFile(@UploadedFile() file: Express.Multer.File) {
    await this.coreFieldsService.syncFieldsWithExcel(file.path);
    return { message: 'File uploaded and processed successfully' };
  }
}
