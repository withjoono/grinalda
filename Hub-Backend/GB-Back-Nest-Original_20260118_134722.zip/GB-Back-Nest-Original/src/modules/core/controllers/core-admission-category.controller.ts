import {
  Controller,
  Get,
  Post,
  Delete,
  Body,
  Param,
  ParseIntPipe,
  Patch,
} from '@nestjs/common';
import { CoreAdmissionCategoryService } from '../services/core-admission-category.service';
import { AdmissionCategoryEntity } from 'src/database/entities/core/admission-category.entity';
import {
  CreateAdmissionCategoryDto,
  UpdateAdmissionCategoryDto,
} from '../dtos/admission-category.dto';

@Controller('core/admission-categories')
export class CoreAdmissionCategoryController {
  constructor(
    private readonly admissionCategoryService: CoreAdmissionCategoryService,
  ) {}

  @Get()
  async findAll(): Promise<AdmissionCategoryEntity[]> {
    return this.admissionCategoryService.findAll();
  }

  @Get(':id')
  async findOne(
    @Param('id', ParseIntPipe) id: number,
  ): Promise<AdmissionCategoryEntity> {
    return this.admissionCategoryService.findOne(id);
  }

  @Post()
  async create(
    @Body() createAdmissionCategoryDto: CreateAdmissionCategoryDto,
  ): Promise<AdmissionCategoryEntity> {
    return this.admissionCategoryService.create(createAdmissionCategoryDto);
  }

  @Patch(':id')
  async update(
    @Param('id', ParseIntPipe) id: number,
    @Body() updateAdmissionCategoryDto: UpdateAdmissionCategoryDto,
  ): Promise<AdmissionCategoryEntity> {
    return this.admissionCategoryService.update(id, updateAdmissionCategoryDto);
  }

  @Delete(':id')
  async remove(@Param('id', ParseIntPipe) id: number): Promise<void> {
    return this.admissionCategoryService.remove(id);
  }
}
