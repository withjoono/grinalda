import {
  Controller,
  Post,
  UseInterceptors,
  UploadedFile,
  Get,
  Query,
  ParseIntPipe,
  Param,
  Body,
  Patch,
  Delete,
} from '@nestjs/common';
import { Roles } from 'src/auth/decorators/roles.decorator';
import { ApiOperation } from '@nestjs/swagger';
import { FileInterceptor } from '@nestjs/platform-express';
import { diskStorage } from 'multer';
import { extname } from 'path';
import { CoreAdmissionService } from '../services/core-admission.service';
import { AdmissionEntity } from 'src/database/entities/core/admission.entity';
import { CreateAdmissionDto, UpdateAdmissionDto } from '../dtos/admission.dto';

@Controller('core/admission')
export class CoreAdmissionController {
  constructor(private readonly admissionService: CoreAdmissionService) {}

  @Get()
  @ApiOperation({
    summary: '대학별 전형 목록 조회',
  })
  async findAllByUniversity(
    @Query('university_id', ParseIntPipe) universityId: number,
  ): Promise<AdmissionEntity[]> {
    return this.admissionService.findAllByUniversity(universityId);
  }

  @Get(':id')
  @ApiOperation({
    summary: '개별 전형 조회',
  })
  async findOne(
    @Param('id', ParseIntPipe) id: number,
  ): Promise<AdmissionEntity> {
    return this.admissionService.findOne(id);
  }

  @Post()
  @Roles(['ROLE_ADMIN'])
  @ApiOperation({
    summary: '[관리자] 전형 추가',
  })
  async create(
    @Body() createAdmissionDto: CreateAdmissionDto,
  ): Promise<AdmissionEntity> {
    return this.admissionService.create(createAdmissionDto);
  }

  @Patch(':id')
  @Roles(['ROLE_ADMIN'])
  @ApiOperation({
    summary: '[관리자] 전형 수정',
  })
  async update(
    @Param('id', ParseIntPipe) id: number,
    @Body() updateAdmissionDto: UpdateAdmissionDto,
  ): Promise<AdmissionEntity> {
    return this.admissionService.update(id, updateAdmissionDto);
  }

  @Delete(':id')
  @Roles(['ROLE_ADMIN'])
  @ApiOperation({
    summary: '[관리자] 전형 삭제',
  })
  async remove(@Param('id', ParseIntPipe) id: number): Promise<void> {
    return this.admissionService.remove(id);
  }

  @Post('upload/subject')
  @Roles(['ROLE_ADMIN'])
  @ApiOperation({
    summary: '[관리자] 대학 전형(교과) 목록 엑셀 업로드',
  })
  @UseInterceptors(
    FileInterceptor('file', {
      storage: diskStorage({
        destination: './uploads',
        filename: (req, file, cb) => {
          const uniqueSuffix =
            Date.now() + '-' + Math.round(Math.random() * 1e9);
          cb(null, `${uniqueSuffix}${extname(file.originalname)}`);
        },
      }),
    }),
  )
  async uploadSubjectFile(@UploadedFile() file: Express.Multer.File) {
    await this.admissionService.syncSubjectAdmissionsWithExcel(file.path);
    return { message: 'File uploaded and processed successfully' };
  }

  @Post('upload/comprehensive')
  @Roles(['ROLE_ADMIN'])
  @ApiOperation({
    summary: '[관리자] 대학 전형(학종) 목록 엑셀 업로드',
  })
  @UseInterceptors(
    FileInterceptor('file', {
      storage: diskStorage({
        destination: './uploads',
        filename: (req, file, cb) => {
          const uniqueSuffix =
            Date.now() + '-' + Math.round(Math.random() * 1e9);
          cb(null, `${uniqueSuffix}${extname(file.originalname)}`);
        },
      }),
    }),
  )
  async uploadComprehensiveFile(@UploadedFile() file: Express.Multer.File) {
    await this.admissionService.syncComprehensiveAdmissionsWithExcel(file.path);
    return { message: 'File uploaded and processed successfully' };
  }
}
