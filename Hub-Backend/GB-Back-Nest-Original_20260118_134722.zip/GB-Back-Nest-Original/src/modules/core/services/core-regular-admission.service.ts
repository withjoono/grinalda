import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import * as XLSX from 'xlsx';
import * as fs from 'fs';
import { RegularAdmissionEntity } from 'src/database/entities/core/regular-admission.entity';
import { UniversityEntity } from 'src/database/entities/core/university.entity';
import {
  CreateRegularAdmissionDto,
  UpdateRegularAdmissionDto,
} from '../dtos/regular-admission.dto';
import { RegularAdmissionPreviousResultEntity } from 'src/database/entities/core/regular-admission-previous-result.entity';

@Injectable()
export class CoreRegularAdmissionService {
  constructor(
    @InjectRepository(RegularAdmissionEntity)
    private regularAdmissionRepository: Repository<RegularAdmissionEntity>,
    @InjectRepository(RegularAdmissionPreviousResultEntity)
    private regularAdmissionPreviousResultRepository: Repository<RegularAdmissionPreviousResultEntity>,
    @InjectRepository(UniversityEntity)
    private universityRepository: Repository<UniversityEntity>,
  ) {}

  async findAll(): Promise<RegularAdmissionEntity[]> {
    return this.regularAdmissionRepository.find({
      relations: ['university'],
    });
  }

  async findOne(id: number): Promise<RegularAdmissionEntity> {
    const admission = await this.regularAdmissionRepository.findOne({
      where: { id },
      relations: ['university'],
    });
    if (!admission) {
      throw new NotFoundException(`Regular Admission with ID ${id} not found`);
    }
    return admission;
  }

  async create(
    createRegularAdmissionDto: CreateRegularAdmissionDto,
  ): Promise<RegularAdmissionEntity> {
    const { university_id, ...admissionData } = createRegularAdmissionDto;
    const university = await this.universityRepository.findOneOrFail({
      where: { id: university_id },
    });

    const admission = this.regularAdmissionRepository.create({
      ...admissionData,
      university,
    });

    return this.regularAdmissionRepository.save(admission);
  }

  async update(
    id: number,
    updateRegularAdmissionDto: UpdateRegularAdmissionDto,
  ): Promise<RegularAdmissionEntity> {
    const admission = await this.findOne(id);
    const { university_id, ...admissionData } = updateRegularAdmissionDto;

    if (university_id) {
      const university = await this.universityRepository.findOneOrFail({
        where: { id: university_id },
      });
      admission.university = university;
    }

    Object.assign(admission, admissionData);
    return this.regularAdmissionRepository.save(admission);
  }

  async remove(id: number): Promise<void> {
    const admission = await this.findOne(id);
    await this.regularAdmissionRepository.remove(admission);
  }

  async syncWithExcel(filePath: string): Promise<void> {
    const YEAR = 2024;
    const queryRunner =
      this.regularAdmissionRepository.manager.connection.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await queryRunner.manager.delete(RegularAdmissionEntity, { year: YEAR });
      await queryRunner.manager.delete(RegularAdmissionPreviousResultEntity, {
        year: YEAR,
      });

      const workbook = XLSX.readFile(filePath);
      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];
      const data = XLSX.utils.sheet_to_json(sheet, { header: 'A' });

      let errorCount = 0;

      for (let i = 2; i < data.length; i++) {
        const row = data[i];
        const universityCode = row['CG'];
        // const universityCode = row['CH'];
        const universityRegion = row['A'];
        const universityName = row['B'];
        const year = YEAR;
        const admissionName = (row['C'] || '').trim();
        const admissionType = (row['D'] || '').trim();
        const generalFieldName = (row['E'] || '').trim();
        const detailedFields = (row['F'] || '').trim();
        const recruitmentNumber = parseInt(row['H']) || 0;
        const recruitmentName = (row['G'] || '').trim();
        const selection_method = (row['I'] || '').trim();
        // 선발 방식
        const csatRatio = (row['J'] + '' || '').trim();
        const schoolRecordRatio = (row['K'] + '' || '').trim();
        const interviewRatio = (row['L'] + '' || '').trim();
        const otherRatio = (row['M'] + '' || '').trim();
        const scoreCalculation = (row['CD'] || '').trim();
        // const scoreCalculation = (row['CE'] || '').trim();
        const csatElements = (row['N'] + '' || '').trim();
        const csatCombination = (row['O'] + '' || '').trim();
        const csatRequired = (row['P'] + '' || '').trim();
        const csatOptional = (row['O'] + '' || '').trim();
        const totalScore = row['CE'] !== 'N' ? parseInt(row['CE'] || '0') : 0;
        // const totalScore = row['CF'] !== 'N' ? parseInt(row['CF'] || '0') : 0;
        const researchSubjectCount =
          row['R'] !== 'N' ? parseInt(row['R'] || '0') : 0;
        const korean_reflection_score =
          row['S'] !== 'N'
            ? parseFloat(parseFloat(row['S'] || '0').toFixed(5))
            : 0;
        const math_reflection_score =
          row['T'] !== 'N'
            ? parseFloat(parseFloat(row['T'] || '0').toFixed(5))
            : 0;
        const research_reflection_score =
          row['V'] !== 'N'
            ? parseFloat(parseFloat(row['V'] || '0').toFixed(5))
            : 0;
        const english_reflection_score =
          row['U'] !== 'N'
            ? parseFloat(parseFloat(row['U'] || '0').toFixed(5))
            : 0;
        const korean_history_reflection_score =
          row['W'] !== 'N'
            ? parseFloat(parseFloat(row['W'] || '0').toFixed(5))
            : 0;
        const second_foreign_language_reflection_score =
          row['X'] !== 'N'
            ? parseFloat(parseFloat(row['X'] || '0').toFixed(5))
            : 0;
        const minCut = parseFloat(parseFloat(row['BD'] || '0').toFixed(5));
        const minCutPercent = parseFloat(
          parseFloat(row['BE'] || '0').toFixed(5),
        );
        const maxCut = parseFloat(parseFloat(row['BF'] || '0').toFixed(5));
        const maxCutPercent = parseFloat(
          parseFloat(row['BG'] || '0').toFixed(5),
        );
        const risk_plus_5 = parseFloat(parseFloat(row['BH'] || '0').toFixed(5));
        const risk_plus_4 = parseFloat(parseFloat(row['BI'] || '0').toFixed(5));
        const risk_plus_3 = parseFloat(parseFloat(row['BJ'] || '0').toFixed(5));
        const risk_plus_2 = parseFloat(parseFloat(row['BK'] || '0').toFixed(5));
        const risk_plus_1 = parseFloat(parseFloat(row['BL'] || '0').toFixed(5));
        const risk_minus_1 = parseFloat(
          parseFloat(row['BM'] || '0').toFixed(5),
        );
        const risk_minus_2 = parseFloat(
          parseFloat(row['BN'] || '0').toFixed(5),
        );
        const risk_minus_3 = parseFloat(
          parseFloat(row['BO'] || '0').toFixed(5),
        );
        const risk_minus_4 = parseFloat(
          parseFloat(row['BP'] || '0').toFixed(5),
        );
        const risk_minus_5 = parseFloat(
          parseFloat(row['BQ'] || '0').toFixed(5),
        );
        const initial_cumulative_percentile = parseFloat(
          parseFloat(row['BE'] || '0').toFixed(5),
        );
        const additional_cumulative_percentile = parseFloat(
          parseFloat(row['BG'] || '0').toFixed(5),
        );
        const korean_elective_subject = row['Y'] || '';
        const math_elective_subject = row['Z'] || '';
        const math_probability_statistics_additional_points = row['AA'] || '';
        const math_calculus_additional_points = row['AB'] || '';
        const math_geometry_additional_points = row['AC'] || '';
        const research_type = row['AD'] || '';
        const research_social_additional_points = row['AE'] || '';
        const research_science_additional_points = row['AF'] || '';
        const math_research_selection = row['AG'] || '';
        const english_application_criteria = row['AH'] || '';
        const english_grade_1_score = row['AI'] || '';
        const english_grade_2_score = row['AJ'] || '';
        const english_grade_3_score = row['AK'] || '';
        const english_grade_4_score = row['AL'] || '';
        const english_grade_5_score = row['AM'] || '';
        const english_grade_6_score = row['AN'] || '';
        const english_grade_7_score = row['AO'] || '';
        const english_grade_8_score = row['AP'] || '';
        const english_grade_9_score = row['AQ'] || '';
        const english_minimum_criteria = row['AR'] || '';
        const korean_history_application_criteria = row['AS'] || '';
        const korean_history_grade_1_score = row['AT'] || '';
        const korean_history_grade_2_score = row['AU'] || '';
        const korean_history_grade_3_score = row['AV'] || '';
        const korean_history_grade_4_score = row['AW'] || '';
        const korean_history_grade_5_score = row['AX'] || '';
        const korean_history_grade_6_score = row['AY'] || '';
        const korean_history_grade_7_score = row['AZ'] || '';
        const korean_history_grade_8_score = row['BA'] || '';
        const korean_history_grade_9_score = row['BB'] || '';
        const korean_history_minimum_criteria = row['BC'] || '';

        if (universityCode === 'N') {
          ++errorCount;
          console.log(
            '대학 정보가 없습니다: ',
            i,
            universityName,
            admissionName,
            admissionType,
            scoreCalculation,
          );
          continue;
        }

        let university = await this.universityRepository.findOne({
          where: { code: universityCode },
        });
        if (!university) {
          university = await this.universityRepository.save(
            this.universityRepository.create({
              code: universityCode,
              name: universityName,
              region: universityRegion,
              establishment_type: '',
            }),
          );
          console.log('대학 생성', university);
        }

        const newAdmission = this.regularAdmissionRepository.create({
          university,
          year,
          admission_name: admissionName,
          admission_type: admissionType,
          general_field_name: generalFieldName,
          detailed_fields: detailedFields,
          recruitment_number: recruitmentNumber,
          recruitment_name: recruitmentName,
          selection_method,
          csat_ratio: csatRatio,
          school_record_ratio: schoolRecordRatio,
          interview_ratio: interviewRatio,
          other_ratio: otherRatio,
          score_calculation: scoreCalculation,
          csat_elements: csatElements,
          csat_combination: csatCombination,
          csat_required: csatRequired,
          csat_optional: csatOptional,
          total_score: totalScore,
          research_subject_count: researchSubjectCount,
          korean_reflection_score,
          math_reflection_score,
          research_reflection_score,
          min_cut: minCut,
          min_cut_percent: minCutPercent,
          max_cut: maxCut,
          max_cut_percent: maxCutPercent,
          risk_plus_5,
          risk_plus_4,
          risk_plus_3,
          risk_plus_2,
          risk_plus_1,
          risk_minus_1,
          risk_minus_2,
          risk_minus_3,
          risk_minus_4,
          risk_minus_5,
          initial_cumulative_percentile,
          additional_cumulative_percentile,
          english_reflection_score,
          korean_history_reflection_score,
          second_foreign_language_reflection_score,
          korean_elective_subject,
          math_elective_subject,
          math_calculus_additional_points,
          math_probability_statistics_additional_points,
          math_geometry_additional_points,
          research_type,
          research_social_additional_points,
          research_science_additional_points,
          math_research_selection,
          english_application_criteria,
          english_grade_1_score,
          english_grade_2_score,
          english_grade_3_score,
          english_grade_4_score,
          english_grade_5_score,
          english_grade_6_score,
          english_grade_7_score,
          english_grade_8_score,
          english_grade_9_score,
          english_minimum_criteria,
          korean_history_application_criteria,
          korean_history_grade_1_score,
          korean_history_grade_2_score,
          korean_history_grade_3_score,
          korean_history_grade_4_score,
          korean_history_grade_5_score,
          korean_history_grade_6_score,
          korean_history_grade_7_score,
          korean_history_grade_8_score,
          korean_history_grade_9_score,
          korean_history_minimum_criteria,
        });

        await queryRunner.manager.save(RegularAdmissionEntity, newAdmission);

        // 과거 입학 결과 추가
        const previousResults = [
          {
            year: 2024,
            min_cut: parseFloat(row['BT'] || '0') || null,
            max_cut: null,
            competition_ratio: parseFloat(row['BR'] || '0') || null,
            percent: parseFloat(row['BU'] || '0') || null,
            recruitment_number: parseInt(row['BS']) || null,
          },
          {
            year: 2023,
            min_cut: parseFloat(row['BX'] || '0') || null,
            max_cut: null,
            competition_ratio: parseFloat(row['BV'] || '0') || null,
            percent: parseFloat(row['BY'] || '0') || null,
            recruitment_number: parseInt(row['BW']) || null,
          },
          {
            year: 2022,
            min_cut: parseFloat(row['CB'] || '0') || null,
            max_cut: null,
            competition_ratio: parseFloat(row['BZ'] || '0') || null,
            percent: parseFloat(row['CC'] || '0') || null,
            recruitment_number: parseInt(row['CA']) || null,
          },
        ];

        if (previousResults.length > 0) {
          for (const result of previousResults) {
            const previousResult =
              this.regularAdmissionPreviousResultRepository.create({
                ...result,
                regular_admission: newAdmission,
              });
            await queryRunner.manager.save(
              RegularAdmissionPreviousResultEntity,
              previousResult,
            );
          }
        }

        console.log(i, '개 처리 완료');
      }

      await queryRunner.commitTransaction();
      console.log(
        `2024년 정시 전형 데이터 동기화 완료 (성공: ${data.length - 2 - errorCount}, 스킵: ${errorCount})`,
      );
    } catch (error) {
      await queryRunner.rollbackTransaction();
      console.error('정시 전형 데이터 동기화 중 오류 발생:', error);
      throw error;
    } finally {
      await queryRunner.release();
      fs.unlinkSync(filePath);
    }
  }
}
