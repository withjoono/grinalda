import { IsNotEmpty, IsString, IsNumber } from 'class-validator';

export class GetMockExamStandardScoreDto {
  @IsString()
  @IsNotEmpty()
  code: string; // 과목코드

  @IsNumber()
  @IsNotEmpty()
  grade: number; // 등급

  @IsString()
  standard_score: string; // 표준점수

  @IsNumber()
  percentile: number; // 백분위
}
