import { Controller, Get, Param, ParseIntPipe, Query } from '@nestjs/common';
import { ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { SusiComprehensiveService } from '../services/susi-comprehensive.service';
import { SusiComprehensiveStep1ResponseDto } from '../dtos/susi-comprehensive-step-1.dto';
import {
  SusiComprehensiveStep2QueryDto,
  SusiComprehensiveStep2ResponseDto,
} from '../dtos/susi-comprehensive-step-2.dto';
import {
  SusiComprehensiveStep3QueryDto,
  SusiComprehensiveStep3ResponseDto,
} from '../dtos/susi-comprehensive-step-3.dto';
import { SusiComprehensiveEntity } from 'src/database/entities/susi/susi-comprehensive.entity';
import {
  SusiComprehensiveStep4QueryDto,
  SusiComprehensiveStep4ResponseDto,
} from '../dtos/susi-comprehensive-step-4.dto';
import { SusiPassRecordEntity } from 'src/database/entities/susi/susi-pass-record.entity';

@ApiTags('[유저] 수시 학종 조회')
@Controller('susi/comprehensive')
export class SusiComprehensiveController {
  constructor(
    private readonly susiComprehensiveService: SusiComprehensiveService,
  ) {}

  @Get('step-1')
  @ApiOperation({
    summary: '[수시 학종] Step 1 대학조회(기본유형, 대계열, 중계열, 소계열)',
  })
  async getSusiComprehensiveStep_1(
    @Query('year', ParseIntPipe) year,
    @Query('basic_type') basic_type,
    @Query('large_department') large_department,
    @Query('medium_department') medium_department,
    @Query('small_department') small_department,
  ): Promise<SusiComprehensiveStep1ResponseDto[]> {
    const data = await this.susiComprehensiveService.getSusiComprehensiveStep_1(
      {
        year,
        basic_type,
        large_department,
        medium_department,
        small_department,
      },
    );
    return data;
  }

  @Get('step-2')
  @ApiOperation({
    summary: '[수시 학종] Step 2 대학 비교과 정보 조회(비율)',
  })
  async getSusiComprehensiveStep_2(
    @Query() dto: SusiComprehensiveStep2QueryDto,
  ): Promise<SusiComprehensiveStep2ResponseDto[]> {
    const data = await this.susiComprehensiveService.getSusiComprehensiveStep_2(
      { ids: dto.ids },
    );
    return data;
  }

  @Get('step-3')
  @ApiOperation({
    summary: '[수시 학종] Step 3 최저등급 데이터 조회',
  })
  async getSusiComprehensiveStep_3(
    @Query() dto: SusiComprehensiveStep3QueryDto,
  ): Promise<SusiComprehensiveStep3ResponseDto[]> {
    const data = await this.susiComprehensiveService.getSusiComprehensiveStep_3(
      { ids: dto.ids },
    );
    return data;
  }

  @Get('step-4')
  @ApiOperation({
    summary: '[수시 학종] Step 4 전형일자 데이터 조회',
  })
  async getSusiComprehensiveStep_4(
    @Query() dto: SusiComprehensiveStep4QueryDto,
  ): Promise<SusiComprehensiveStep4ResponseDto[]> {
    const data = await this.susiComprehensiveService.getSusiComprehensiveStep_4(
      { ids: dto.ids },
    );
    return data;
  }

  @Get('detail/:id')
  @ApiOperation({
    summary: '[수시 학종] 상세 페이지 조회',
  })
  @ApiResponse({ status: 403, description: 'Forbidden.' })
  async getSusiSubjectDetail(
    @Param('id', ParseIntPipe) id: number,
  ): Promise<SusiComprehensiveEntity> {
    const data =
      await this.susiComprehensiveService.getSusiComprehensiveDetail(id);
    return data;
  }

  @Get('pass-record/:id')
  @ApiOperation({
    summary: '[수시 학종] 합불 사례 조회',
  })
  async getSusiSubjectPassRecord(
    @Param('id', ParseIntPipe) id: number,
  ): Promise<SusiPassRecordEntity[]> {
    const data =
      await this.susiComprehensiveService.getSusiSubjectPassRecords(id);
    return data;
  }
}
