import { IsNotEmpty, IsOptional, IsString } from 'class-validator';

export class PayPreRegisterDto {
  @IsString()
  @IsNotEmpty()
  product_id: string;

  @IsString()
  @IsOptional()
  coupon_number?: string;
}
