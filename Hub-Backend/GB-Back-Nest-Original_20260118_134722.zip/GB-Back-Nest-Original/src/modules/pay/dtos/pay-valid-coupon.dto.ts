import { IsNotEmpty, IsNumber, IsString } from 'class-validator';

export class PayValidCouponDto {
  @IsString()
  @IsNotEmpty()
  coupon_number: string;

  @IsString()
  @IsNotEmpty()
  product_id: string;
}

export class PayValidCouponResponseDto {
  @IsNumber()
  @IsNotEmpty()
  discount_price: number;

  @IsString()
  @IsNotEmpty()
  coupon_info: string;
}
