import {
  Controller,
  Post,
  Body,
  Get,
  Param,
  ParseIntPipe,
  HttpException,
  HttpStatus,
} from '@nestjs/common';
import { PaymentService } from './pay.service';
import { AllConfigType } from 'src/config/config.type';
import { ConfigService } from '@nestjs/config';
import {
  PayValidCouponDto,
  PayValidCouponResponseDto,
} from './dtos/pay-valid-coupon.dto';
import { PayPreRegisterDto } from './dtos/pay-pre-register.dto';
import { PayVerifyDto } from './dtos/pay-verify.dto';
import { CouponService } from './services/coupon.service';
import { PayHistoryDto } from './dtos/pay-history.dto';
import { Public } from 'src/auth/decorators/public.decorator';
import { CurrentMemberId } from 'src/auth/decorators/current-member_id.decorator';
import { Roles } from 'src/auth/decorators/roles.decorator';

@Controller('payments')
export class PaymentController {
  constructor(
    private readonly paymentService: PaymentService,
    private readonly couponService: CouponService,
    private configService: ConfigService<AllConfigType>,
  ) {}

  @Get('history')
  async getMemberPaymentHistories(
    @CurrentMemberId() memberId: string,
  ): Promise<PayHistoryDto[]> {
    const history = await this.paymentService.getMemberPaymentHistories(
      Number(memberId),
    );

    return history;
  }

  @Get('history/:id')
  async getMemberPaymentHistory(
    @CurrentMemberId() memberId: string,
    @Param('id', ParseIntPipe) orderId: number,
  ): Promise<PayHistoryDto> {
    const history = await this.paymentService.getMemberPaymentHistory(
      Number(memberId),
      orderId,
    );

    return history;
  }

  @Post('pre-register')
  async preRegisterPayment(
    @Body() body: PayPreRegisterDto,
    @CurrentMemberId() memberId: string,
  ) {
    const { coupon_number, product_id } = body;
    const payOrder = await this.paymentService.preRegisterPayment(
      Number(product_id),
      Number(memberId),
      coupon_number,
    );
    return payOrder;
  }

  @Post('verify')
  async verifyPayment(
    @Body()
    body: PayVerifyDto,
  ) {
    const { imp_uid, merchant_uid, coupon_number } = body;
    const paymentInfo = await this.paymentService.verifyAndProcessPayment(
      imp_uid,
      merchant_uid,
      coupon_number,
    );

    return paymentInfo;
  }

  @Get('store-code')
  getStoreCode() {
    return {
      storeCode: this.configService.getOrThrow('pay', { infer: true })
        .impStoreCode,
    };
  }

  // 쿠폰 검증 및 실제 할인금액 반환
  @Post('coupon/valid')
  async validCoupon(
    @Body() body: PayValidCouponDto,
  ): Promise<PayValidCouponResponseDto> {
    const paymentInfo = await this.couponService.validCoupon({
      coupon_number: body.coupon_number,
      product_id: Number(body.product_id),
    });

    return paymentInfo;
  }

  // 무료가로 구매
  @Post('free')
  async contractFreeService(
    @Body() body: PayValidCouponDto,
    @CurrentMemberId() memberId: string,
  ): Promise<void> {
    const paymentInfo = await this.paymentService.contractFreeService(
      {
        coupon_number: body.coupon_number,
        product_id: Number(body.product_id),
      },
      Number(memberId),
    );

    return paymentInfo;
  }

  // 결제 후처리 웹훅
  @Post('/webhook')
  @Public()
  async handleWebhook(@Body() webhookData: any) {
    const { imp_uid, merchant_uid, status } = webhookData;

    try {
      await this.paymentService.processWebhook(imp_uid, merchant_uid, status);
      return { message: '웹훅이 성공적으로 처리되었습니다.' };
    } catch (error) {
      console.error('웹훅 처리 중 오류 발생:', error);
      throw new HttpException(
        '웹훅 처리 중 오류가 발생했습니다.',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  @Get('inquire/:merchantUid')
  @Roles(['ROLE_ADMIN'])
  async inquirePayment(@Param('merchantUid') merchantUid: string) {
    return this.paymentService.inquireAndProcessPayment(merchantUid);
  }
}
