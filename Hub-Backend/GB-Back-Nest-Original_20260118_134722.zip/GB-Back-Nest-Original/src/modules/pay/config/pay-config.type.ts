export type PayConfig = {
  impKey?: string;
  impSecret?: string;
  impStoreCode?: string;
};
