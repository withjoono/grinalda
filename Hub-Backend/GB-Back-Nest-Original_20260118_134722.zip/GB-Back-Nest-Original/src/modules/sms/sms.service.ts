import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { BadRequestException, Inject, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import axios from 'axios';
import { Cache } from 'cache-manager';
import { WINSTON_MODULE_PROVIDER } from 'nest-winston';
import { AllConfigType } from 'src/config/config.type';
import { Logger } from 'winston';

@Injectable()
export class SmsService {
  private readonly AuthData: {
    key: string;
    user_id: string;
    sender: string;
    testmode_yn?: string;
  };

  constructor(
    private configService: ConfigService<AllConfigType>,
    @Inject(CACHE_MANAGER) private cacheManager: Cache,
    @Inject(WINSTON_MODULE_PROVIDER) private readonly logger: Logger,
  ) {
    this.AuthData = {
      key: this.configService.getOrThrow('sms', { infer: true }).aligoApiKey,
      user_id: this.configService.getOrThrow('sms', { infer: true })
        .aligoUserId,
      sender: this.configService.getOrThrow('sms', { infer: true })
        .aligoSenderPhone,
      testmode_yn: this.configService.getOrThrow('sms', { infer: true })
        .aligoTestMode,
    };
  }

  // 인증코드 확인
  async verifyCode(phone: string, code: string): Promise<boolean> {
    const storedCode = await this.cacheManager.get<string>(phone);
    if (storedCode && storedCode === code) {
      await this.cacheManager.del(phone); // 코드 일치 시 삭제
      return true;
    }
    return false;
  }

  // 회원가입 인증번호 발송
  async sendRegisterCode(phone: string, branch?: string) {
    const code = this._generateCode();
    console.log(code);
    await this._saveCodeToCache(phone, code);
    let message = `[(주)]거북스쿨 본인확인 인증번호 [${code}]를 화면에 입력해주세요.`;
    if (branch === 'ida') {
      message = `대치IDA학원 본인확인 인증번호 [${code}]를 화면에 입력해주세요.`;
    }
    return this.sendMessage(message, phone);
  }

  // 랜덤 인증코드 생성
  private _generateCode(): string {
    return Math.floor(100000 + Math.random() * 900000).toString(); // 6자리 랜덤 숫자 코드 생성
  }

  // 인증코드 캐시저장(180초)
  private async _saveCodeToCache(phone: string, code: string) {
    await this.cacheManager.set(phone, code, 180 * 1000); // 코드 180초 동안 캐시에 저장
  }

  private async _sendRequest(uri: string, requestData: any) {
    const data = { ...this.AuthData, ...requestData };
    try {
      const response = await axios.post(uri, data, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data || error.message);
    }
  }

  // 메세지 발송
  async sendMessage(message: string, receiverPhone: string) {
    const uri = 'https://apis.aligo.in/send/';
    const result = await this._sendRequest(uri, {
      msg: message,
      receiver: receiverPhone,
    });
    this.logger.info(`메세지 발송결과 : ${message} ${receiverPhone} ${result}`);
    if (!(result.result_code === '1' || result.result_code === 1)) {
      throw new BadRequestException(result.message);
    }
    return result;
  }
}
