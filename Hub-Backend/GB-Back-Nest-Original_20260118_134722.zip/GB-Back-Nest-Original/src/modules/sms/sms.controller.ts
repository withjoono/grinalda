import { Body, Controller, Post } from '@nestjs/common';
import { AllConfigType } from 'src/config/config.type';
import { ConfigService } from '@nestjs/config';
import { Roles } from 'src/auth/decorators/roles.decorator';
import { SmsService } from './sms.service';

@Controller('sms')
export class SmsController {
  constructor(
    private readonly smsService: SmsService,
    private configService: ConfigService<AllConfigType>,
  ) {}

  @Post('send')
  @Roles(['ROLE_ADMIN'])
  async sendMessage(@Body() body: { message: string; receiverPhone: string }) {
    await this.smsService.sendMessage(body.message, body.receiverPhone);

    return;
  }
}
