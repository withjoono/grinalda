import { registerAs } from '@nestjs/config';
import { IsOptional, IsString } from 'class-validator';
import { SMSConfig } from './sms-config.type';
import { validateConfig } from 'src/common/utils/validate-config';

class EnvironmentVariablesValidator {
  @IsString()
  ALIGO_API_KEY: string;

  @IsString()
  ALIGO_USER_ID: string;

  @IsString()
  ALIGO_SENDER_PHONE: string;

  @IsString()
  @IsOptional()
  ALIGO_TEST_MODE: string;
}

export default registerAs<SMSConfig>('sms', () => {
  validateConfig(process.env, EnvironmentVariablesValidator);

  return {
    aligoApiKey: process.env.ALIGO_API_KEY,
    aligoUserId: process.env.ALIGO_USER_ID,
    aligoSenderPhone: process.env.ALIGO_SENDER_PHONE,
    aligoTestMode:
      process.env.AUTH_REFRESH_TOKEN_EXPIRES_IN === 'true' ? 'Y' : 'N',
  };
});
