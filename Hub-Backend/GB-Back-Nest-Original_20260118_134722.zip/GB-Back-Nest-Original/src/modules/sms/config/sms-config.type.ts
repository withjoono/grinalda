export type SMSConfig = {
  aligoApiKey?: string;
  aligoUserId?: string;
  aligoSenderPhone?: string;
  aligoTestMode?: string;
};
