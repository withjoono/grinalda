import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { PayServiceEntity } from 'src/database/entities/pay/pay-service.entity';
import { Repository } from 'typeorm';

@Injectable()
export class StoreService {
  constructor(
    @InjectRepository(PayServiceEntity)
    private readonly payServiceRepository: Repository<PayServiceEntity>,
  ) {}

  async findAll(): Promise<PayServiceEntity[]> {
    return await this.payServiceRepository.find();
  }

  async findOne(id: number): Promise<PayServiceEntity> {
    return await this.payServiceRepository.findOne({ where: { id } });
  }

  // 판매중인 상품 하나 조회
  async findOneAvailable(id: number): Promise<PayServiceEntity> {
    return await this.payServiceRepository.findOne({
      where: { id, delete_flag: 0 },
    });
  }
  // 판매중인 상품 조회
  async findAvailable(): Promise<PayServiceEntity[]> {
    return await this.payServiceRepository.find({
      where: { delete_flag: 0 },
    });
  }
}
