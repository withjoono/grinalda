import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SchoolRecordService } from './schoolrecord.service';
import { SchoolRecordAttendanceDetailEntity } from 'src/database/entities/schoolrecord/schoolrecord-attendance-detail.entity';
import { SchoolRecordSelectSubjectEntity } from 'src/database/entities/schoolrecord/schoolrecord-select-subject.entity';
import { SchoolRecordSubjectLearningEntity } from 'src/database/entities/schoolrecord/schoolrecord-subject-learning.entity';
import { SchoolRecordVolunteerEntity } from 'src/database/entities/schoolrecord/schoolrecord-volunteer.entity';
import { SchoolRecordController } from './schoolrecord.controller';
import { SchoolrecordSportsArtEntity } from 'src/database/entities/schoolrecord/schoolrecord-sport-art.entity';
import { MemberEntity } from 'src/database/entities/member/member.entity';
import { AwsUploadModule } from 'src/aws-upload/aws-upload.module';
import { MemberUploadFileListEntity } from 'src/database/entities/member/member-file';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      SchoolRecordAttendanceDetailEntity,
      SchoolRecordSelectSubjectEntity,
      SchoolRecordSubjectLearningEntity,
      SchoolRecordVolunteerEntity,
      SchoolrecordSportsArtEntity,
      MemberEntity,
      MemberUploadFileListEntity,
    ]),
    AwsUploadModule,
  ],
  controllers: [SchoolRecordController],
  providers: [SchoolRecordService],
  exports: [SchoolRecordService],
})
export class SchoolRecordModule {}
