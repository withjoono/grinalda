import {
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Query,
  UploadedFile,
  UseInterceptors,
} from '@nestjs/common';
import { SchoolRecordService } from './schoolrecord.service';
import { FileInterceptor } from '@nestjs/platform-express';
import { CurrentMemberId } from 'src/auth/decorators/current-member_id.decorator';
import { Roles } from 'src/auth/decorators/roles.decorator';
import { PaginationDto } from 'src/common/dtos/pagination.dto';

@Controller('schoolrecord')
export class SchoolRecordController {
  constructor(private readonly schoolRecordService: SchoolRecordService) {}

  @Get('files')
  @Roles(['ROLE_ADMIN'])
  async getAllSchoolRecordFiles(
    @Query() paginationDto: PaginationDto & { searchKey?: string },
  ) {
    const page = Number(paginationDto.page) || 1;
    const limit = Number(paginationDto.limit) || 10;
    const { searchKey } = paginationDto;
    const skip = (page - 1) * limit;

    const [files, total] = await this.schoolRecordService.getMemberUploadFiles(
      skip,
      limit,
      searchKey,
    );

    return {
      files,
      total,
      page,
      limit,
    };
  }

  @Post('upload/pdf')
  @UseInterceptors(FileInterceptor('file'))
  async uploadSchoolRecordPdf(
    @UploadedFile() file: Express.Multer.File,
    @CurrentMemberId() memberId: string,
  ) {
    const uploadedFileUrl =
      await this.schoolRecordService.uploadSchoolRecordPdf(memberId, file);
    return { url: uploadedFileUrl };
  }

  @Get('access')
  @Roles(['ROLE_ADMIN'])
  async getFileAccess(@Query('fileKey') fileKey: string) {
    const signedUrl =
      await this.schoolRecordService.getSchoolRecordFile(fileKey);
    return { signedUrl };
  }

  @Delete(':schoolRecordId')
  @Roles(['ROLE_ADMIN'])
  async deleteSchoolRecord(@Param('schoolRecordId') schoolRecordId: string) {
    return this.schoolRecordService.deleteSchoolRecordById(schoolRecordId);
  }
}
