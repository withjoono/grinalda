export enum AuthProviderEnum {
  email = 'local',
  google = 'google',
  naver = 'naver',
}
