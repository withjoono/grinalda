export enum MemberRoleEnum {
  user = 'ROLE_USER',
  admin = 'ROLE_ADMIN',
}
