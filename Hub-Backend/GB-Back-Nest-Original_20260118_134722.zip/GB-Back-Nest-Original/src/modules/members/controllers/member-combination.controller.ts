import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  ParseIntPipe,
  UseGuards,
} from '@nestjs/common';
import { ApiOperation } from '@nestjs/swagger';
import { MemberRecruitmentUnitCombinationService } from '../services/member-combination.service';
import {
  CreateMemberRecruitmentUnitCombinationDto,
  MemberRecruitmentUnitCombinationResponseDto,
  UpdateMemberRecruitmentUnitCombinationDto,
} from '../dtos/combination.dto';
import { CurrentMemberId } from 'src/auth/decorators/current-member_id.decorator';
import { MemberPermissionGuard } from '../guards/user-permission.guard';

@Controller('members/:memberId/combinations')
export class MemberCombinationController {
  constructor(
    private readonly memberCombinationService: MemberRecruitmentUnitCombinationService,
  ) {}

  @Post()
  @UseGuards(MemberPermissionGuard)
  @ApiOperation({ summary: '모집단위 조합 생성' })
  async create(
    @CurrentMemberId() memberId: string,
    @Body()
    createMemberCombinationDto: CreateMemberRecruitmentUnitCombinationDto,
  ): Promise<MemberRecruitmentUnitCombinationResponseDto> {
    return this.memberCombinationService.create(
      memberId,
      createMemberCombinationDto,
    );
  }

  @Get()
  @UseGuards(MemberPermissionGuard)
  @ApiOperation({ summary: '모집단위 조합 목록 조회' })
  async findAll(
    @CurrentMemberId() memberId: string,
  ): Promise<MemberRecruitmentUnitCombinationResponseDto[]> {
    return this.memberCombinationService.findAll(memberId);
  }

  @Get(':id')
  @UseGuards(MemberPermissionGuard)
  @ApiOperation({ summary: '특정 모집단위 조합 조회' })
  async findOne(
    @CurrentMemberId() memberId: string,
    @Param('id', ParseIntPipe) id: number,
  ): Promise<MemberRecruitmentUnitCombinationResponseDto> {
    return this.memberCombinationService.findOne(id, memberId);
  }

  @Patch(':id')
  @UseGuards(MemberPermissionGuard)
  @ApiOperation({ summary: '모집단위 조합 수정' })
  async update(
    @CurrentMemberId() memberId: string,
    @Param('id', ParseIntPipe) id: number,
    @Body()
    updateMemberCombinationDto: UpdateMemberRecruitmentUnitCombinationDto,
  ): Promise<MemberRecruitmentUnitCombinationResponseDto> {
    return this.memberCombinationService.update(
      memberId,
      id,
      updateMemberCombinationDto,
    );
  }

  @Delete(':id')
  @UseGuards(MemberPermissionGuard)
  @ApiOperation({ summary: '모집단위 조합 삭제' })
  async remove(
    @CurrentMemberId() memberId: string,
    @Param('id', ParseIntPipe) id: number,
  ): Promise<void> {
    await this.memberCombinationService.remove(memberId, id);
  }
}
