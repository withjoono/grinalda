import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  ParseIntPipe,
  UseGuards,
} from '@nestjs/common';
import { ApiOperation } from '@nestjs/swagger';
import { CurrentMemberId } from 'src/auth/decorators/current-member_id.decorator';
import { MemberPermissionGuard } from '../guards/user-permission.guard';
import { MemberRegularCombinationService } from '../services/member-regular-combination.service';
import {
  CreateMemberRegularCombinationDto,
  UpdateMemberRegularCombinationDto,
} from '../dtos/regular-combination.dto';
import { MemberRegularCombinationEntity } from 'src/database/entities/member/member-regular-combination.entity';

@Controller('members/:memberId/regular-combinations')
export class MemberRegularCombinationController {
  constructor(
    private readonly memberCombinationService: MemberRegularCombinationService,
  ) {}

  @Post()
  @UseGuards(MemberPermissionGuard)
  @ApiOperation({ summary: '모집단위 조합 생성' })
  async create(
    @CurrentMemberId() memberId: string,
    @Body()
    createMemberCombinationDto: CreateMemberRegularCombinationDto,
  ): Promise<MemberRegularCombinationEntity> {
    return this.memberCombinationService.create(
      memberId,
      createMemberCombinationDto,
    );
  }

  @Get()
  @UseGuards(MemberPermissionGuard)
  @ApiOperation({ summary: '모집단위 조합 목록 조회' })
  async findAll(
    @CurrentMemberId() memberId: string,
  ): Promise<MemberRegularCombinationEntity[]> {
    return this.memberCombinationService.findAll(memberId);
  }

  @Get(':id')
  @UseGuards(MemberPermissionGuard)
  @ApiOperation({ summary: '특정 모집단위 조합 조회' })
  async findOne(
    @CurrentMemberId() memberId: string,
    @Param('id', ParseIntPipe) id: number,
  ): Promise<MemberRegularCombinationEntity> {
    return this.memberCombinationService.findOne(id, memberId);
  }

  @Patch(':id')
  @UseGuards(MemberPermissionGuard)
  @ApiOperation({ summary: '모집단위 조합 수정' })
  async update(
    @CurrentMemberId() memberId: string,
    @Param('id', ParseIntPipe) id: number,
    @Body()
    updateMemberCombinationDto: UpdateMemberRegularCombinationDto,
  ): Promise<MemberRegularCombinationEntity> {
    return this.memberCombinationService.update(
      memberId,
      id,
      updateMemberCombinationDto,
    );
  }

  @Delete(':id')
  @UseGuards(MemberPermissionGuard)
  @ApiOperation({ summary: '모집단위 조합 삭제' })
  async remove(
    @CurrentMemberId() memberId: string,
    @Param('id', ParseIntPipe) id: number,
  ): Promise<void> {
    await this.memberCombinationService.remove(memberId, id);
  }
}
