import { Body, Controller, Patch, SerializeOptions } from '@nestjs/common';
import { MembersService } from '../services/members.service';
import { ApiOperation } from '@nestjs/swagger';
import { CurrentMemberId } from 'src/auth/decorators/current-member_id.decorator';
import { EditProfileDto } from '../dtos/edit-profile.dto';
import { EditLifeRecordDto } from '../dtos/edit-life-record.dto';
import { SchoolRecordService } from 'src/modules/schoolrecord/schoolrecord.service';

@Controller('members')
export class MembersController {
  constructor(
    private readonly membersService: MembersService,
    private readonly schoolRecordService: SchoolRecordService,
  ) {}

  @ApiOperation({
    summary: '유저 프로필 수정',
  })
  @SerializeOptions({
    groups: ['me'],
  })
  @Patch('profile')
  async editProfile(
    @Body() body: EditProfileDto,
    @CurrentMemberId() memberId: string,
  ) {
    await this.membersService.editProfile(memberId, body);
    return null;
  }

  @ApiOperation({
    summary: '유저 생기부 수정',
  })
  @Patch('life-record')
  async editLifeRecord(
    @CurrentMemberId() memberId: string,
    @Body() editLifeRecordDto: EditLifeRecordDto,
  ) {
    await this.schoolRecordService.editLifeRecord(memberId, editLifeRecordDto);
    return null;
  }
}
