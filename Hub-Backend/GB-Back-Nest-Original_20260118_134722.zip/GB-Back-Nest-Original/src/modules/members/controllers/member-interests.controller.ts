import {
  Controller,
  Post,
  Get,
  Delete,
  Param,
  Body,
  UseGuards,
  Query,
} from '@nestjs/common';
import { MemberInterestsService } from '../services/member-interests.service';
import { AddInterestDto } from '../dtos/add-interest.dto';
import { RemoveInterestDto } from '../dtos/remove-interest.dto';
import { InterestSusiSubjectResponse } from '../dtos/interest-susi-subject-response';
import { MemberPermissionGuard } from '../guards/user-permission.guard';
import { InterestSusiComprehensiveResponse } from '../dtos/interest-susi-comprehensive-response';
import { ApiOperation } from '@nestjs/swagger';

@Controller('members/:memberId/interests')
export class MemberInterestsController {
  constructor(
    private readonly memberInterestsService: MemberInterestsService,
  ) {}

  @ApiOperation({
    summary:
      '관심 대학 목록에 대학 추가 (테이블명: susi_comprehensive_tb | susi_subject_tb)',
  })
  @Post()
  @UseGuards(MemberPermissionGuard)
  async addInterest(
    @Body() body: AddInterestDto,
    @Param('memberId') memberId: number,
  ) {
    await this.memberInterestsService.addInterest(
      memberId,
      body.targetTable,
      body.targetIds,
      body.evaluation_id,
    );
    return null;
  }

  @Delete()
  @UseGuards(MemberPermissionGuard)
  async removeInterest(
    @Body() body: RemoveInterestDto,
    @Param('memberId') memberId: number,
  ) {
    await this.memberInterestsService.removeInterest(
      memberId,
      body.targetTable,
      body.targetIds,
    );
    return null;
  }

  @Get('/susi-subject')
  @UseGuards(MemberPermissionGuard)
  async getInterestsSusiSubject(
    @Param('memberId') memberId: number,
  ): Promise<InterestSusiSubjectResponse[]> {
    return this.memberInterestsService.getSusiSubject(memberId);
  }

  @Get('/susi-comprehensive')
  @UseGuards(MemberPermissionGuard)
  async getInterestsSusiComprehensive(
    @Param('memberId') memberId: number,
  ): Promise<InterestSusiComprehensiveResponse[]> {
    return this.memberInterestsService.getSusiComprehensive(memberId);
  }

  @Get('')
  @UseGuards(MemberPermissionGuard)
  async getIntersetRecruitmentUnits(
    @Param('memberId') memberId: number,
    @Query('admissionType')
    admissionType:
      | 'susi_subject_tb'
      | 'susi_comprehensive_tb'
      | 'early_subject'
      | 'early_comprehensive',
  ) {
    return this.memberInterestsService.getIntersetRecruitmentUnits(
      memberId,
      admissionType,
    );
  }
}
