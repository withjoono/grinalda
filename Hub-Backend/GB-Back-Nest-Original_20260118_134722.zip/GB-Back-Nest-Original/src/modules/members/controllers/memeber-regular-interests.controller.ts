import {
  Controller,
  Post,
  Get,
  Delete,
  Param,
  Body,
  UseGuards,
  Query,
} from '@nestjs/common';
import { MemberPermissionGuard } from '../guards/user-permission.guard';
import { ApiOperation } from '@nestjs/swagger';
import {
  AddRegularInterestDto,
  RemoveRegularInterestDto,
} from '../dtos/regular-interest.dto';
import { MemberRegularInterestsService } from '../services/member-regular-interests.service';

@Controller('members/:memberId/regular-interests')
export class MemberRegularInterestsController {
  constructor(
    private readonly memberRegularInterestsService: MemberRegularInterestsService,
  ) {}

  @ApiOperation({
    summary: '관심 대학 목록에 대학 추가 (전형타입: 가 | 나 | 다)',
  })
  @Post()
  @UseGuards(MemberPermissionGuard)
  async addInterest(
    @Body() body: AddRegularInterestDto,
    @Param('memberId') memberId: number,
  ) {
    await this.memberRegularInterestsService.addInterest(
      memberId,
      body.admissionType,
      body.targetIds,
    );
    return null;
  }

  @Delete()
  @UseGuards(MemberPermissionGuard)
  async removeInterest(
    @Body() body: RemoveRegularInterestDto,
    @Param('memberId') memberId: number,
  ) {
    await this.memberRegularInterestsService.removeInterest(
      memberId,
      body.admissionType,
      body.targetIds,
    );
    return null;
  }

  @Get('')
  @UseGuards(MemberPermissionGuard)
  async getIntersetRecruitmentUnits(
    @Param('memberId') memberId: number,
    @Query('admissionType')
    admissionType: '가' | '나' | '다',
  ) {
    return this.memberRegularInterestsService.getRegularInterests(
      memberId,
      admissionType,
    );
  }
}
