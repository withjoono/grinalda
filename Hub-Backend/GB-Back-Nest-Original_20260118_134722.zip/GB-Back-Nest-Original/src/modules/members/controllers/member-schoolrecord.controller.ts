import { Controller, Get, Param, UseGuards } from '@nestjs/common';
import { MemberPermissionGuard } from '../guards/user-permission.guard';
import { SchoolRecordService } from 'src/modules/schoolrecord/schoolrecord.service';

@Controller('members/:memberId/schoolrecord')
export class MemberSchoolRecordController {
  constructor(private readonly schoolRecordService: SchoolRecordService) {}

  // 학생부 출결 데이터 조회
  @Get('attendance')
  @UseGuards(MemberPermissionGuard)
  async getAttendanceDetails(@Param('memberId') memberId: number) {
    return await this.schoolRecordService.getAttendanceDetails(memberId);
  }

  // 학생부 선택과목 데이터 조회
  @Get('select-subject')
  @UseGuards(MemberPermissionGuard)
  async getSelectSubjects(@Param('memberId') memberId: number) {
    return await this.schoolRecordService.getSelectSubjects(memberId);
  }

  // 학생부 기본과목 데이터 조회
  @Get('subject')
  @UseGuards(MemberPermissionGuard)
  async getSubjectLearnings(@Param('memberId') memberId: number) {
    return await this.schoolRecordService.getSubjectLearnings(memberId);
  }

  // 학생부 봉사 데이터 조회
  @Get('volunteers')
  @UseGuards(MemberPermissionGuard)
  async getVolunteers(@Param('memberId') memberId: number) {
    return await this.schoolRecordService.getVolunteers(memberId);
  }

  // 학생부 체육&미술 데이터 조회
  @Get('sport-art')
  @UseGuards(MemberPermissionGuard)
  async getSportArts(@Param('memberId') memberId: number) {
    return await this.schoolRecordService.getSportArts(memberId);
  }
}
