import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EssayListEntity } from 'src/database/entities/essay/essay-list.entity';
import { EssayService } from './essay.service';
import { EssayLowestGradeListEntity } from 'src/database/entities/essay/essay-lowest-grade-list.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([EssayListEntity, EssayLowestGradeListEntity]),
  ],
  providers: [EssayService],
  exports: [EssayService],
})
export class EssayModule {}
