import { Injectable, Inject } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { Cache } from 'cache-manager';
import { RegularAdmissionEntity } from 'src/database/entities/core/regular-admission.entity';

@Injectable()
export class ExploreRegularService {
  constructor(
    @InjectRepository(RegularAdmissionEntity)
    private readonly regularAdmissionRepository: Repository<RegularAdmissionEntity>,
    @Inject(CACHE_MANAGER) private cacheManager: Cache,
  ) {}

  async getAdmissions(year: string, admissionType: string) {
    const cacheKey = `explore-jungsi-admission:university:${year}-${admissionType}`;
    const cachedData = await this.cacheManager.get(cacheKey);

    if (cachedData) {
      return cachedData;
    }

    const queryBuilder = this.regularAdmissionRepository
      .createQueryBuilder('regularAdmission')
      .leftJoinAndSelect('regularAdmission.university', 'university')
      .where('regularAdmission.year = :year', { year })
      .andWhere('regularAdmission.admission_type = :admissionType', {
        admissionType,
      });

    const regularAdmissions = await queryBuilder.getMany();

    await this.cacheManager.set(
      cacheKey,
      { items: regularAdmissions },
      120 * 60 * 1000,
    ); // 120분 캐시

    return { items: regularAdmissions };
  }

  async getAdmission(regularId: number) {
    const admission = this.regularAdmissionRepository.findOne({
      where: {
        id: regularId,
      },
      relations: ['university', 'previous_results'],
    });

    return admission;
  }
}
