import { DatabaseConfig } from 'src/database/config/database-config.type';
import { AppConfig } from './app-config.type';
import { AuthConfig } from 'src/auth/config/auth-config.type';
import { PayConfig } from 'src/modules/pay/config/pay-config.type';
import { SMSConfig } from 'src/modules/sms/config/sms-config.type';
import { AwsUploadConfig } from 'src/aws-upload/config/aws-upload-config.type';

export type AllConfigType = {
  app: AppConfig;
  database: DatabaseConfig;
  auth: AuthConfig;
  pay: PayConfig;
  sms: SMSConfig;
  awsUpload: AwsUploadConfig;
};
