import { NestFactory, Reflector } from '@nestjs/core';
import { AppModule } from './app.module';
import { ConfigService } from '@nestjs/config';
import { AllConfigType } from './config/config.type';
import { ClassSerializerInterceptor, ValidationPipe } from '@nestjs/common';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import * as Sentry from '@sentry/node';
import { SentryInterceptor } from './common/interceptors/sentry.interceptor';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  const configService = app.get(ConfigService<AllConfigType>);
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true, // DTO에 정의된 필드만 받아들임
      forbidNonWhitelisted: true, // 정의되지 않은 필드가 포함되어 있으면 요청을 거부
      transform: true, // 요청데이터를 자동으로 변환
    }),
  );

  // ClassSerializerInterceptor를 전역으로 사용
  app.useGlobalInterceptors(new ClassSerializerInterceptor(app.get(Reflector)));

  // SentryInterceptor에 Logger를 주입
  const logger = app.get(WINSTON_MODULE_NEST_PROVIDER);
  app.useGlobalInterceptors(new SentryInterceptor(logger));

  // Swagger 문서 설정
  const config = new DocumentBuilder()
    .setTitle('거북스쿨 API')
    .setVersion('1.0')
    .build();
  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('swagger', app, document);

  app.enableCors({
    origin: [
      // 허용할 도메인
      'https://turtleschool-admin-front.vercel.app',
      'https://admin2.turtleskool.com',
      'https://turtleskool.com',
      'https://turtleanp.com',
      'https://turtlemedi.com',
      'https://ts-front.vercel.app',
      'http://localhost:5173',
      'http://localhost:4173',
      'http://localhost:3000',
      'http://localhost:4000',
      'https://idaacademy.vercel.app',
    ],
    methods: ['GET', 'HEAD', 'PUT', 'PATCH', 'POST', 'DELETE', 'OPTIONS'],
    credentials: true, // 자격 증명 허용
  });

  Sentry.init({
    dsn: process.env.SENTRY_DSN,
  });

  const PORT = configService.getOrThrow('app', { infer: true }).port;
  await app.listen(PORT);
}
bootstrap();
