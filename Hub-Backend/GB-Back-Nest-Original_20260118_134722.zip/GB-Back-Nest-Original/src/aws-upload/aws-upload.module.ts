import { Module } from '@nestjs/common';
import { AwsUploadService } from './aws-upload.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AdditionalFileController } from './controllers/additional-file-upload.controller';
import { MemberUploadFileListEntity } from 'src/database/entities/member/member-file';
import { OfficerListEntity } from 'src/database/entities/officer-evaluation/officer-list.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([MemberUploadFileListEntity, OfficerListEntity]),
    AwsUploadModule,
  ],
  controllers: [AdditionalFileController],
  providers: [AwsUploadService],
  exports: [AwsUploadService],
})
export class AwsUploadModule {}
