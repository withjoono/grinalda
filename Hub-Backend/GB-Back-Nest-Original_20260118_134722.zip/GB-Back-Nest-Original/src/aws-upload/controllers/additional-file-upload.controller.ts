import {
  Controller,
  Post,
  Get,
  UseInterceptors,
  UploadedFile,
  Param,
  BadRequestException,
  NotFoundException,
  Delete,
  UnauthorizedException,
  Query,
  ParseIntPipe,
  Req,
  Inject,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { MemberUploadFileListEntity } from 'src/database/entities/member/member-file';
import { AwsUploadService } from '../aws-upload.service';
import { CurrentMemberId } from 'src/auth/decorators/current-member_id.decorator';
import { OfficerListEntity } from 'src/database/entities/officer-evaluation/officer-list.entity';
import { Logger } from 'winston';
import { WINSTON_MODULE_PROVIDER } from 'nest-winston';

const MAX_FILE_SIZE = 15 * 1024 * 1024;
const MAX_FILES_PER_USER = 5;
const FILE_TYPE = 'ADDITIONAL';

@Controller('additional-files')
export class AdditionalFileController {
  constructor(
    private readonly awsUploadService: AwsUploadService,
    @InjectRepository(MemberUploadFileListEntity)
    private memberUploadFileListRepository: Repository<MemberUploadFileListEntity>,
    @InjectRepository(OfficerListEntity)
    private officerListRepository: Repository<OfficerListEntity>,
    @Inject(WINSTON_MODULE_PROVIDER) private readonly logger: Logger,
  ) {}

  @Post('upload')
  @UseInterceptors(FileInterceptor('file'))
  async uploadFile(
    @UploadedFile() file: Express.Multer.File,
    @CurrentMemberId() memberId: string,
    @Req() req: any,
  ) {
    if (!file) {
      this.logger.warn(`id: ${memberId}님이 파일 없이 업로드 시도를 했습니다.`);
      throw new BadRequestException('파일이 제공되지 않았습니다.');
    }

    if (file.size > MAX_FILE_SIZE) {
      this.logger.warn(
        `id: ${memberId}님이 파일 크기 초과(${file.size})로 업로드 시도를 했습니다.`,
      );
      throw new BadRequestException('파일 크기는 15MB를 초과할 수 없습니다.');
    }

    const existingFiles = await this.memberUploadFileListRepository.find({
      where: { member_id: Number(memberId), file_type: FILE_TYPE },
    });

    if (existingFiles.length >= MAX_FILES_PER_USER) {
      this.logger.warn(
        `id: ${memberId}님이 최대 파일 업로드 개수를 초과했습니다.`,
      );
      throw new BadRequestException(
        '추가 자료는 최대 5개까지만 업로드할 수 있습니다.',
      );
    }
    // req.body를 통해 FormData에 포함된 파일명을 가져오기
    const encodedFileName = req.body.fileName;
    const decodedFileName = decodeURIComponent(encodedFileName);

    const fileKey = await this.awsUploadService.uploadFile(
      file,
      'additional',
      decodedFileName,
    );
    const newFile = this.memberUploadFileListRepository.create({
      file_key: fileKey,
      file_name: decodedFileName,
      file_path: fileKey,
      file_size: file.size,
      file_type: FILE_TYPE,
      member_id: Number(memberId),
    });

    await this.memberUploadFileListRepository.save(newFile);

    this.logger.info(
      `id: ${memberId}님이 ${decodedFileName} 파일 업로드 성공: 파일 크기 ${file.size} bytes`,
    );

    return { message: '파일이 성공적으로 업로드되었습니다.', fileKey };
  }

  @Get('list')
  async getUploadedFiles(@CurrentMemberId() memberId: string) {
    const files = await this.memberUploadFileListRepository.find({
      where: { member_id: Number(memberId), file_type: FILE_TYPE },
      select: ['id', 'file_name', 'file_size', 'create_dt'],
    });

    return files;
  }

  @Get('download/:id')
  async getDownloadUrl(
    @Param('id', ParseIntPipe) id: number,
    @CurrentMemberId() memberId: string,
  ) {
    this.logger.info(
      `id: ${memberId}님이 파일 다운로드를 요청했습니다. 파일 ID: ${id}`,
    );
    const file = await this.memberUploadFileListRepository.findOne({
      where: { id, member_id: Number(memberId), file_type: FILE_TYPE },
    });

    if (!file) {
      this.logger.error(
        `id: ${memberId}님이 요청한 파일(ID: ${id})을 찾을 수 없습니다.`,
      );
      throw new NotFoundException('파일을 찾을 수 없습니다.');
    }

    const signedUrl = await this.awsUploadService.getSignedUrl(file.file_key);
    this.logger.info(
      `id: ${memberId}님이 파일 다운로드 URL을 성공적으로 가져왔습니다. 파일명: ${file.file_name}`,
    );

    return { url: signedUrl, fileName: file.file_name };
  }

  @Delete(':id')
  async deleteFile(
    @Param('id', ParseIntPipe) id: number,
    @CurrentMemberId() memberId: string,
  ) {
    this.logger.info(
      `id: ${memberId}님이 파일 삭제를 요청했습니다. 파일 ID: ${id}`,
    );
    const file = await this.memberUploadFileListRepository.findOne({
      where: { id, member_id: Number(memberId), file_type: FILE_TYPE },
    });

    if (!file) {
      this.logger.error(
        `id: ${memberId}님이 삭제하려는 파일(ID: ${id})을 찾을 수 없습니다.`,
      );
      throw new NotFoundException('파일을 찾을 수 없습니다.');
    }

    // S3에서 파일 삭제
    await this.awsUploadService.deleteFile(file.file_key);

    // 데이터베이스에서 파일 정보 삭제
    await this.memberUploadFileListRepository.remove(file);

    this.logger.info(
      `id: ${memberId}님이 파일(ID: ${id})을 성공적으로 삭제했습니다.`,
    );

    return { message: '파일이 성공적으로 삭제되었습니다.' };
  }

  // 사정관용 다른 사용자의 파일 목록 조회
  @Get('officer/list')
  async getOfficerFileList(
    @CurrentMemberId() curMemberId: string,
    @Query('memberId', ParseIntPipe) memberId: number,
  ) {
    this.logger.info(
      `사정관 ID: ${curMemberId}님이 사용자 ID: ${memberId}의 파일 목록을 조회하려고 합니다.`,
    );

    const officer = await this.officerListRepository.findOne({
      where: { member_id: Number(curMemberId), del_yn: 'N' },
    });

    if (!officer) {
      this.logger.error(
        `사정관 ID: ${curMemberId}님이 권한 없이 파일 목록 조회를 시도했습니다.`,
      );
      throw new UnauthorizedException('사정관 권한이 없습니다.');
    }

    const files = await this.memberUploadFileListRepository.find({
      where: { member_id: memberId, file_type: FILE_TYPE },
      select: ['id', 'file_name', 'file_size', 'create_dt'],
    });
    this.logger.info(
      `사정관 ID: ${curMemberId}님이 사용자 ID: ${memberId}의 파일 목록을 성공적으로 조회했습니다.`,
    );

    return files;
  }

  // 사정관용 다른 사용자의 파일 다운로드
  @Get('officer/download/:id')
  async officerDownloadFile(
    @Param('id', ParseIntPipe) id: number,
    @CurrentMemberId() curMemberId: string,
  ) {
    this.logger.info(
      `사정관 ID: ${curMemberId}님이 파일 다운로드를 요청했습니다. 파일 ID: ${id}`,
    );

    const officer = await this.officerListRepository.findOne({
      where: { member_id: Number(curMemberId), del_yn: 'N' },
    });

    if (!officer) {
      this.logger.error(
        `사정관 ID: ${curMemberId}님이 권한 없이 파일 다운로드를 시도했습니다.`,
      );
      throw new UnauthorizedException('사정관 권한이 없습니다.');
    }

    const file = await this.memberUploadFileListRepository.findOne({
      where: { id, file_type: FILE_TYPE },
    });

    if (!file) {
      this.logger.error(
        `사정관 ID: ${curMemberId}님이 다운로드하려는 파일(ID: ${id})을 찾을 수 없습니다.`,
      );
      throw new NotFoundException('파일을 찾을 수 없습니다.');
    }

    const signedUrl = await this.awsUploadService.getSignedUrl(file.file_key);
    this.logger.info(
      `사정관 ID: ${curMemberId}님이 파일 다운로드 URL을 성공적으로 가져왔습니다. 파일명: ${file.file_name}`,
    );

    return { url: signedUrl, fileName: file.file_name };
  }
}
