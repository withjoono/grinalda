import { registerAs } from '@nestjs/config';
import { validateConfig } from '../../common/utils/validate-config';
import { AwsUploadConfig } from './aws-upload-config.type';
import { IsString } from 'class-validator';

class EnvironmentVariablesValidator {
  @IsString()
  AWS_ACCESS_KEY_ID: string;

  @IsString()
  AWS_SECRET_ACCESS_KEY: string;

  @IsString()
  AWS_REGION: string;

  @IsString()
  AWS_S3_BUCKET_NAME: string;
}

export default registerAs<AwsUploadConfig>('awsUpload', () => {
  validateConfig(process.env, EnvironmentVariablesValidator);

  return {
    accessKey: process.env.AWS_ACCESS_KEY_ID,
    secretKey: process.env.AWS_SECRET_ACCESS_KEY,
    region: process.env.AWS_REGION,
    bucketName: process.env.AWS_S3_BUCKET_NAME,
  };
});
