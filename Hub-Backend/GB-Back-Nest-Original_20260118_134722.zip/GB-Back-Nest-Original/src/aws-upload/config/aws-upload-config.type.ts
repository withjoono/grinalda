export type AwsUploadConfig = {
  accessKey: string;
  secretKey: string;
  region: string;
  bucketName: string;
};
