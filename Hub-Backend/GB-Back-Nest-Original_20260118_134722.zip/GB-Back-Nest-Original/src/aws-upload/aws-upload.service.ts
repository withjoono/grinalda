import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import {
  S3Client,
  PutObjectCommand,
  ObjectCannedACL,
  GetObjectCommand,
  DeleteObjectCommand,
} from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { AllConfigType } from 'src/config/config.type';

@Injectable()
export class AwsUploadService {
  private s3Client: S3Client;

  constructor(private configService: ConfigService<AllConfigType>) {
    this.s3Client = new S3Client({
      region: this.configService.getOrThrow('awsUpload', { infer: true })
        .region,
      credentials: {
        accessKeyId: this.configService.getOrThrow('awsUpload', { infer: true })
          .accessKey,
        secretAccessKey: this.configService.getOrThrow('awsUpload', {
          infer: true,
        }).secretKey,
      },
    });
  }

  async uploadFile(
    file: Express.Multer.File,
    folder: string,
    name?: string,
  ): Promise<string> {
    const bucketName = this.configService.getOrThrow('awsUpload', {
      infer: true,
    }).bucketName;

    const fileName = `${folder}/${Date.now()}-${name || file.originalname}`;

    const params = {
      Bucket: bucketName,
      Key: fileName,
      Body: file.buffer,
      ContentType: file.mimetype,
      ACL: ObjectCannedACL.private, // 또는 ObjectCannedACL.public_read
    };

    try {
      const command = new PutObjectCommand(params);
      await this.s3Client.send(command);

      return fileName;
    } catch (error) {
      console.error('Error uploading file to S3:', error);
      throw new Error('Failed to upload file to S3');
    }
  }

  async getSignedUrl(fileKey: string): Promise<string> {
    const bucketName = this.configService.getOrThrow('awsUpload', {
      infer: true,
    }).bucketName;

    const command = new GetObjectCommand({
      Bucket: bucketName,
      Key: fileKey,
    });

    try {
      // URL의 유효 시간을 설정합니다 (예: 1시간)
      const signedUrl = await getSignedUrl(this.s3Client, command, {
        expiresIn: 3600,
      });
      return signedUrl;
    } catch (error) {
      console.error('Error generating signed URL:', error);
      throw new Error('Failed to generate signed URL');
    }
  }

  async deleteFile(fileKey: string): Promise<void> {
    const bucketName = this.configService.getOrThrow('awsUpload', {
      infer: true,
    }).bucketName;

    const deleteParams = {
      Bucket: bucketName,
      Key: fileKey,
    };

    try {
      const command = new DeleteObjectCommand(deleteParams);
      await this.s3Client.send(command);
    } catch (error) {
      console.error('Error deleting file from S3:', error);
      throw new Error('Failed to delete file from S3');
    }
  }
}
