import { Module } from '@nestjs/common';
import { AuthService } from './auth.service';
import { AuthController } from './auth.controller';
import { JwtModule } from 'src/common/jwt/jwt.module';
import { PassportModule } from '@nestjs/passport';
import { JwtStrategy } from './strategies/jwt.strategy';
import { MembersModule } from 'src/modules/members/members.module';
import { BcryptModule } from 'src/common/bcrypt/bcrypt.module';
import { HttpModule } from '@nestjs/axios';
import { SmsModule } from 'src/modules/sms/sms.module';

@Module({
  imports: [
    MembersModule,
    BcryptModule,
    JwtModule,
    PassportModule,
    HttpModule,
    SmsModule,
  ],
  providers: [AuthService, JwtStrategy],
  controllers: [AuthController],
})
export class AuthModule {}
