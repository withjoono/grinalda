export type SocialUser = {
  id: string;
  name?: string;
  email?: string;
  profile_image?: string;
};
