import { IsIn, IsNotEmpty, IsString } from 'class-validator';

export class LoginWithSocialDto {
  @IsString()
  @IsNotEmpty()
  @IsIn(['naver', 'google'])
  socialType: string;

  @IsString()
  @IsNotEmpty()
  accessToken: string;
}
