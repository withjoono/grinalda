import {
  IsEmail,
  IsNotEmpty,
  IsString,
  MaxLength,
  MinLength,
} from 'class-validator';

export class loginWithEmailDto {
  @IsEmail()
  @IsNotEmpty()
  email: string;

  @IsString()
  @MinLength(6, {
    message: 'Password is too short. It must be at least 6 characters long.',
  })
  @MaxLength(500, {
    message: 'Password is too long. It must be at most 500 characters long.',
  })
  password: string;
}
