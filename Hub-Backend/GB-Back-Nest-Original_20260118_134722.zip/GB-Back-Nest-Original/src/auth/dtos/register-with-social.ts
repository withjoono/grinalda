import {
  IsBoolean,
  IsIn,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator';

export class RegisterWithSocialDto {
  @IsString()
  @IsNotEmpty()
  @IsIn(['naver', 'google'])
  socialType: 'naver' | 'google';

  @IsString()
  @IsNotEmpty()
  accessToken: string;

  @IsString()
  @IsNotEmpty()
  nickname: string; // 이름

  @IsString()
  @IsNotEmpty()
  phone: string; // 휴대폰 번호

  @IsBoolean()
  @IsNotEmpty()
  ckSmsAgree: boolean; // sms 수신 동의

  @IsString()
  @IsNotEmpty()
  @IsIn(['0', '1'], {
    message: '전공 코드가 잘못되었습니다. (문과: 0, 이과: 1)',
  })
  isMajor: string; // 문과(0), 이과(1)

  @IsNumber()
  @IsOptional()
  hstTypeId: number; // 고등학교 코드

  @IsString()
  @IsNotEmpty()
  graduateYear: string; // 졸업(예정)년도

  @IsString()
  @IsOptional()
  @IsIn(['student', 'teacher', 'parent'])
  memberType?: string; // student, teacher, parent
}
