import { IsEmail, IsNotEmpty, IsOptional, IsString } from 'class-validator';

export class SendSignupCodeDto {
  @IsEmail()
  @IsOptional()
  email?: string;

  @IsString()
  @IsNotEmpty()
  phone: string;
}
