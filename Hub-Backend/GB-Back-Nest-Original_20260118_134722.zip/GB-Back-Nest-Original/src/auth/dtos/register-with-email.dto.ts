import {
  IsBoolean,
  IsEmail,
  IsIn,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  MaxLength,
  MinLength,
} from 'class-validator';

export class RegisterWithEmailDto {
  @IsEmail()
  @IsNotEmpty()
  email: string;

  @IsString()
  @MinLength(6, {
    message: 'Password is too short. It must be at least 6 characters long.',
  })
  @MaxLength(500, {
    message: 'Password is too long. It must be at most 500 characters long.',
  })
  password: string;

  @IsString()
  @IsNotEmpty()
  nickname: string; // 이름

  @IsString()
  @IsNotEmpty()
  phone: string; // 휴대폰 번호

  @IsBoolean()
  @IsNotEmpty()
  ckSmsAgree: boolean; // sms 수신 동의

  @IsString()
  @IsNotEmpty()
  @IsIn(['0', '1'], {
    message: '전공 코드가 잘못되었습니다. (문과: 0, 이과: 1)',
  })
  isMajor: string; // 문과(0), 이과(1)

  @IsNumber()
  @IsOptional()
  hstTypeId: number; // 고등학교 코드

  @IsString()
  @IsNotEmpty()
  graduateYear: string; // 졸업(예정)년도

  @IsString()
  @IsOptional()
  @IsIn(['student', 'teacher', 'parent'])
  memberType?: string; // student, teacher, parent
}
