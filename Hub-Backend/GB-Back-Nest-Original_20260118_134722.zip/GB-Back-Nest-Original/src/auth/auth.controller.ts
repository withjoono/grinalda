import {
  BadGatewayException,
  BadRequestException,
  Body,
  Controller,
  Get,
  Post,
  Query,
  SerializeOptions,
} from '@nestjs/common';
import { AuthService } from './auth.service';
import { loginWithEmailDto } from './dtos/login-with-email.dto';
import { LoginResponseType } from './types/login-response.type';
import { Public } from './decorators/public.decorator';
import { RefreshTokenDto } from './dtos/refresh-token.dto';
import { LoginWithSocialDto } from './dtos/login-with-social.dto';
import { ApiOperation } from '@nestjs/swagger';
import { SmsService } from 'src/modules/sms/sms.service';
import { SendSignupCodeDto } from './dtos/send-signup-code.dto';
import { MembersService } from 'src/modules/members/services/members.service';
import { VerifyCodeDto } from './dtos/verify-code.dto';
import { RegisterWithEmailDto } from './dtos/register-with-email.dto';
import { RegisterWithSocialDto } from './dtos/register-with-social';
import { CurrentMemberId } from './decorators/current-member_id.decorator';
import { MemberEntity } from 'src/database/entities/member/member.entity';

@Controller('auth')
export class AuthController {
  constructor(
    private readonly service: AuthService,
    private readonly smsService: SmsService,
    private readonly membersService: MembersService,
  ) {}

  @ApiOperation({
    summary: '내정보 조회',
  })
  @SerializeOptions({
    groups: ['me'],
  })
  @Get('me')
  public getCurrentMember(
    @CurrentMemberId() memberId: string,
  ): Promise<MemberEntity> {
    return this.membersService.findMeById(Number(memberId));
  }

  @ApiOperation({
    summary: '활성화 중인 서비스 조회',
  })
  @SerializeOptions({
    groups: ['me'],
  })
  @Get('me/active')
  public getCurrentMemberActiveService(
    @CurrentMemberId() memberId: string,
  ): Promise<string[]> {
    return this.membersService.findActiveServicesById(Number(memberId));
  }

  @ApiOperation({
    summary: '이메일로 로그인',
  })
  @SerializeOptions({
    groups: ['me'],
  })
  @Public()
  @Post('login/email')
  public loginWithEmail(
    @Body() loginDto: loginWithEmailDto,
  ): Promise<LoginResponseType> {
    return this.service.validateLogin(loginDto);
  }

  @ApiOperation({
    summary: '이메일로 회원가입',
  })
  @SerializeOptions({
    groups: ['me'],
  })
  @Public()
  @Post('register/email')
  public registerWithEmail(
    @Body() registerDto: RegisterWithEmailDto,
  ): Promise<LoginResponseType> {
    return this.service.registerWithEmail(registerDto);
  }

  @ApiOperation({
    summary: '소셜 로그인',
  })
  @SerializeOptions({
    groups: ['me'],
  })
  @Public()
  @Post('login/social')
  public socialLogin(
    @Body() body: LoginWithSocialDto,
  ): Promise<LoginResponseType> {
    return this.service.validateSocialLogin(body);
  }

  @ApiOperation({
    summary: '소셜 회원가입',
  })
  @SerializeOptions({
    groups: ['me'],
  })
  @Public()
  @Post('register/social')
  public registerWithSocial(
    @Body() registerDto: RegisterWithSocialDto,
  ): Promise<LoginResponseType> {
    return this.service.registerWithSocial(registerDto);
  }

  @ApiOperation({
    summary: 'jwt 토큰 리프레시',
  })
  @Public()
  @Post('refresh')
  async refresh(
    @Body() refreshDto: RefreshTokenDto,
  ): Promise<LoginResponseType> {
    return this.service.refreshToken(refreshDto);
  }

  @ApiOperation({
    summary: '휴대폰 본인인증번호 발송',
  })
  @Public()
  @Post('register/send-code')
  async sendSignupCode(
    @Body() body: SendSignupCodeDto,
    @Query('branch') branch?: string,
  ) {
    if (body.email && (await this.membersService.findOneByEmail(body.email))) {
      throw new BadRequestException('이미 사용중인 이메일입니다.');
    }
    if (
      await this.membersService.findOneByPhone(body.phone.replaceAll('-', ''))
    ) {
      throw new BadRequestException('이미 사용중인 휴대폰입니다.');
    }

    await this.smsService.sendRegisterCode(body.phone, branch);

    return null;
  }

  @ApiOperation({
    summary: '인증코드 확인',
  })
  @Public()
  @Post('verify-code')
  async verifyCode(@Body() verifyDto: VerifyCodeDto) {
    const isValid = await this.smsService.verifyCode(
      verifyDto.phone,
      verifyDto.code,
    );
    if (!isValid) {
      throw new BadGatewayException('인증코드가 일치하지 않습니다.');
    }

    return null;
  }

  @ApiOperation({
    summary: '비밀번호 재설정 인증번호 요청',
  })
  @Public()
  @Post('password-reset-request')
  async passwordResetRequest(
    @Body() body: { email: string; phone: string },
    @Query('branch') branch?: string,
  ) {
    return this.service.requestPasswordResetCode(
      body.email,
      body.phone,
      branch,
    );
  }

  @ApiOperation({
    summary: '비밀번호 재설정 인증번호 확인 및 토큰 발급',
  })
  @Public()
  @Post('verify-reset-code')
  async verifyResetCode(@Body() body: { phone: string; code: string }) {
    return this.service.verifyResetCodeAndCreateToken(body.phone, body.code);
  }

  @ApiOperation({
    summary: '비밀번호 재설정',
  })
  @Public()
  @Post('password-reset')
  async passwordReset(@Body() body: { token: string; newPassword: string }) {
    return this.service.resetPassword(body.token, body.newPassword);
  }
}
