## 거북스쿨 백엔드 Nest

domain: v2.ingipsy.com

admin page: https://admin2.turtleskool.com

### Tasks

### 실행

#### 개발 환경

로컬의 MYSQL DB의 스키마가 적용되지 않았다면 (아예 첫 실행)

- 첫 실행때만 `.env.development` 파일의 DB_SYNCHRONIZE 를 true로 설정
- src/database/database-config.ts에서 아래 설정 주석 후 개발환경 실행
  ```ts
  if (process.env.DB_SYNCHRONIZE === 'true') {
    throw new Error(
      'DB 동기화 설정이 켜져있습니다. DB의 데이터가 날아갈 수 있음으로 서버를 실행시킬 수 없습니다.',
    );
  }
  ```
- 종료 후 주석 및 DB_SYNCHRONIZE 값 원상복구

```sh
yarn start:dev
```

#### 운영 환경 실행

DB_SYNCHRONIZE 값을 true로 설정하지 마세요.

```sh
yarn start:prod
```

### 🔧 환경

- Node 18
- Yarn

### EC2 환경세팅

1. E2 생성 (backend vpc에 생성해야함\*)

2. 보안그룹 설정 (서버 포트 4000 오픈)

3. 도커 설치

```sh
# Docker 설치
sudo yum install -y docker

# ec2-user를 docker 그룹에 추가
sudo usermod -aG docker ec2-user

# Docker 서비스 시작 및 부팅 시 자동 시작 설정
sudo systemctl enable --now docker

# 현재 셸을 새로고침하여 그룹 변경 적용
exec bash

# Docker 데몬이 실행 중인지 확인(안된다면 재연결)
docker ps
```

4. 도커 컴포즈 설치

```sh
# Docker CLI 플러그인 디렉토리 생성
sudo mkdir -p /usr/local/lib/docker/cli-plugins/

# Docker Compose 바이너리 다운로드
sudo curl -SL "https://github.com/docker/compose/releases/latest/download/docker-compose-linux-$(uname -m)" -o /usr/local/lib/docker/cli-plugins/docker-compose

# Docker Compose 바이너리에 실행 권한 추가
sudo chmod +x /usr/local/lib/docker/cli-plugins/docker-compose

# Docker Compose 버전 확인
docker compose version
```

5. Ec2 생성 시 .pem파일 교체 및 깃허브 secrets(SERVER_SSH_KEY) 파일내용으로 수정
